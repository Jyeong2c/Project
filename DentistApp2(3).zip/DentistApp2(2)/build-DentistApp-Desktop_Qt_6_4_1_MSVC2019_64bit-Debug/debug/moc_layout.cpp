/****************************************************************************
** Meta object code from reading C++ file 'layout.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DentistApp/layout.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layout.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Layout_t {
    uint offsetsAndSizes[32];
    char stringdata0[7];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[11];
    char stringdata5[13];
    char stringdata6[15];
    char stringdata7[8];
    char stringdata8[7];
    char stringdata9[8];
    char stringdata10[11];
    char stringdata11[12];
    char stringdata12[19];
    char stringdata13[21];
    char stringdata14[13];
    char stringdata15[4];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Layout_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Layout_t qt_meta_stringdata_Layout = {
    {
        QT_MOC_LITERAL(0, 6),  // "Layout"
        QT_MOC_LITERAL(7, 8),  // "brightUp"
        QT_MOC_LITERAL(16, 0),  // ""
        QT_MOC_LITERAL(17, 13),  // "brightnessLow"
        QT_MOC_LITERAL(31, 10),  // "inverstion"
        QT_MOC_LITERAL(42, 12),  // "verticalFlip"
        QT_MOC_LITERAL(55, 14),  // "horizontalFlip"
        QT_MOC_LITERAL(70, 7),  // "sharpen"
        QT_MOC_LITERAL(78, 6),  // "zoomIn"
        QT_MOC_LITERAL(85, 7),  // "zoomOut"
        QT_MOC_LITERAL(93, 10),  // "leftRotate"
        QT_MOC_LITERAL(104, 11),  // "rightRotate"
        QT_MOC_LITERAL(116, 18),  // "brightnessUpOpenCV"
        QT_MOC_LITERAL(135, 20),  // "brightnessDownOpenCV"
        QT_MOC_LITERAL(156, 12),  // "brightSlider"
        QT_MOC_LITERAL(169, 3)   // "his"
    },
    "Layout",
    "brightUp",
    "",
    "brightnessLow",
    "inverstion",
    "verticalFlip",
    "horizontalFlip",
    "sharpen",
    "zoomIn",
    "zoomOut",
    "leftRotate",
    "rightRotate",
    "brightnessUpOpenCV",
    "brightnessDownOpenCV",
    "brightSlider",
    "his"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Layout[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   98,    2, 0x0a,    1 /* Public */,
       3,    0,   99,    2, 0x0a,    2 /* Public */,
       4,    0,  100,    2, 0x0a,    3 /* Public */,
       5,    0,  101,    2, 0x0a,    4 /* Public */,
       6,    0,  102,    2, 0x0a,    5 /* Public */,
       7,    0,  103,    2, 0x0a,    6 /* Public */,
       8,    0,  104,    2, 0x0a,    7 /* Public */,
       9,    0,  105,    2, 0x0a,    8 /* Public */,
      10,    0,  106,    2, 0x0a,    9 /* Public */,
      11,    0,  107,    2, 0x0a,   10 /* Public */,
      12,    0,  108,    2, 0x0a,   11 /* Public */,
      13,    0,  109,    2, 0x0a,   12 /* Public */,
      14,    1,  110,    2, 0x0a,   13 /* Public */,
      15,    0,  113,    2, 0x0a,   15 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Layout::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Layout.offsetsAndSizes,
    qt_meta_data_Layout,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Layout_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Layout, std::true_type>,
        // method 'brightUp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessLow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inverstion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'verticalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'horizontalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sharpen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomIn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'leftRotate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rightRotate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessUpOpenCV'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessDownOpenCV'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'his'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Layout::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Layout *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->brightUp(); break;
        case 1: _t->brightnessLow(); break;
        case 2: _t->inverstion(); break;
        case 3: _t->verticalFlip(); break;
        case 4: _t->horizontalFlip(); break;
        case 5: _t->sharpen(); break;
        case 6: _t->zoomIn(); break;
        case 7: _t->zoomOut(); break;
        case 8: _t->leftRotate(); break;
        case 9: _t->rightRotate(); break;
        case 10: _t->brightnessUpOpenCV(); break;
        case 11: _t->brightnessDownOpenCV(); break;
        case 12: _t->brightSlider((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->his(); break;
        default: ;
        }
    }
}

const QMetaObject *Layout::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Layout::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Layout.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Layout::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
