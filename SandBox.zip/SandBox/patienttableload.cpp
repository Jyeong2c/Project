#include "patienttableload.h"

PatientTableLoad::PatientTableLoad()
{

}
