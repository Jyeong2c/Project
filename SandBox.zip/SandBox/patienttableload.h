#ifndef PATIENTTABLELOAD_H
#define PATIENTTABLELOAD_H

#include <QObject>

class PatientTableLoad
{
public:
    PatientTableLoad();
};

#endif // PATIENTTABLELOAD_H
