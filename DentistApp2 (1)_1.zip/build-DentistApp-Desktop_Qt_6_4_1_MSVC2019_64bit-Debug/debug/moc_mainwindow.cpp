/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DentistApp/mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[32];
    char stringdata0[11];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[15];
    char stringdata5[32];
    char stringdata6[18];
    char stringdata7[15];
    char stringdata8[5];
    char stringdata9[13];
    char stringdata10[28];
    char stringdata11[32];
    char stringdata12[29];
    char stringdata13[30];
    char stringdata14[34];
    char stringdata15[36];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 10),  // "selectItem"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(40, 14),  // "previousScreen"
        QT_MOC_LITERAL(55, 31),  // "on_imageClearPushButton_clicked"
        QT_MOC_LITERAL(87, 17),  // "layoutSizeChanged"
        QT_MOC_LITERAL(105, 14),  // "QGraphicsView*"
        QT_MOC_LITERAL(120, 4),  // "grid"
        QT_MOC_LITERAL(125, 12),  // "DoubleWidget"
        QT_MOC_LITERAL(138, 27),  // "on_brightToolButton_clicked"
        QT_MOC_LITERAL(166, 31),  // "on_brightnessToolButton_clicked"
        QT_MOC_LITERAL(198, 28),  // "on_sharpenToolButton_clicked"
        QT_MOC_LITERAL(227, 29),  // "on_contrastToolButton_clicked"
        QT_MOC_LITERAL(257, 33),  // "on_verticalFlipToolButton_cli..."
        QT_MOC_LITERAL(291, 35)   // "on_horizontalFlipToolButton_c..."
    },
    "MainWindow",
    "selectItem",
    "",
    "QListWidgetItem*",
    "previousScreen",
    "on_imageClearPushButton_clicked",
    "layoutSizeChanged",
    "QGraphicsView*",
    "grid",
    "DoubleWidget",
    "on_brightToolButton_clicked",
    "on_brightnessToolButton_clicked",
    "on_sharpenToolButton_clicked",
    "on_contrastToolButton_clicked",
    "on_verticalFlipToolButton_clicked",
    "on_horizontalFlipToolButton_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   80,    2, 0x0a,    1 /* Public */,
       4,    0,   83,    2, 0x0a,    3 /* Public */,
       5,    0,   84,    2, 0x08,    4 /* Private */,
       6,    1,   85,    2, 0x08,    5 /* Private */,
       9,    1,   88,    2, 0x08,    7 /* Private */,
      10,    0,   91,    2, 0x08,    9 /* Private */,
      11,    0,   92,    2, 0x08,   10 /* Private */,
      12,    0,   93,    2, 0x08,   11 /* Private */,
      13,    0,   94,    2, 0x08,   12 /* Private */,
      14,    0,   95,    2, 0x08,   13 /* Private */,
      15,    0,   96,    2, 0x08,   14 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'selectItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'previousScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_imageClearPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'layoutSizeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'DoubleWidget'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'on_brightToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_brightnessToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sharpenToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_contrastToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_verticalFlipToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_horizontalFlipToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->selectItem((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 1: _t->previousScreen(); break;
        case 2: _t->on_imageClearPushButton_clicked(); break;
        case 3: _t->layoutSizeChanged((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 4: _t->DoubleWidget((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 5: _t->on_brightToolButton_clicked(); break;
        case 6: _t->on_brightnessToolButton_clicked(); break;
        case 7: _t->on_sharpenToolButton_clicked(); break;
        case 8: _t->on_contrastToolButton_clicked(); break;
        case 9: _t->on_verticalFlipToolButton_clicked(); break;
        case 10: _t->on_horizontalFlipToolButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
