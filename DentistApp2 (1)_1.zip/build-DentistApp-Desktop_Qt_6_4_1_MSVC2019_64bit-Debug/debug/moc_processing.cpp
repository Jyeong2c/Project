/****************************************************************************
** Meta object code from reading C++ file 'processing.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DentistApp/processing.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'processing.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Processing_t {
    uint offsetsAndSizes[36];
    char stringdata0[11];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[11];
    char stringdata5[5];
    char stringdata6[13];
    char stringdata7[15];
    char stringdata8[8];
    char stringdata9[7];
    char stringdata10[8];
    char stringdata11[11];
    char stringdata12[12];
    char stringdata13[19];
    char stringdata14[21];
    char stringdata15[13];
    char stringdata16[4];
    char stringdata17[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Processing_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Processing_t qt_meta_stringdata_Processing = {
    {
        QT_MOC_LITERAL(0, 10),  // "Processing"
        QT_MOC_LITERAL(11, 8),  // "brightUp"
        QT_MOC_LITERAL(20, 0),  // ""
        QT_MOC_LITERAL(21, 13),  // "brightnessLow"
        QT_MOC_LITERAL(35, 10),  // "inverstion"
        QT_MOC_LITERAL(46, 4),  // "item"
        QT_MOC_LITERAL(51, 12),  // "verticalFlip"
        QT_MOC_LITERAL(64, 14),  // "horizontalFlip"
        QT_MOC_LITERAL(79, 7),  // "sharpen"
        QT_MOC_LITERAL(87, 6),  // "zoomIn"
        QT_MOC_LITERAL(94, 7),  // "zoomOut"
        QT_MOC_LITERAL(102, 10),  // "leftRotate"
        QT_MOC_LITERAL(113, 11),  // "rightRotate"
        QT_MOC_LITERAL(125, 18),  // "brightnessUpOpenCV"
        QT_MOC_LITERAL(144, 20),  // "brightnessDownOpenCV"
        QT_MOC_LITERAL(165, 12),  // "brightSlider"
        QT_MOC_LITERAL(178, 3),  // "his"
        QT_MOC_LITERAL(182, 10)   // "imageClear"
    },
    "Processing",
    "brightUp",
    "",
    "brightnessLow",
    "inverstion",
    "item",
    "verticalFlip",
    "horizontalFlip",
    "sharpen",
    "zoomIn",
    "zoomOut",
    "leftRotate",
    "rightRotate",
    "brightnessUpOpenCV",
    "brightnessDownOpenCV",
    "brightSlider",
    "his",
    "imageClear"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Processing[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x0a,    1 /* Public */,
       3,    0,  105,    2, 0x0a,    2 /* Public */,
       4,    1,  106,    2, 0x0a,    3 /* Public */,
       6,    0,  109,    2, 0x0a,    5 /* Public */,
       7,    0,  110,    2, 0x0a,    6 /* Public */,
       8,    0,  111,    2, 0x0a,    7 /* Public */,
       9,    0,  112,    2, 0x0a,    8 /* Public */,
      10,    0,  113,    2, 0x0a,    9 /* Public */,
      11,    0,  114,    2, 0x0a,   10 /* Public */,
      12,    0,  115,    2, 0x0a,   11 /* Public */,
      13,    0,  116,    2, 0x0a,   12 /* Public */,
      14,    0,  117,    2, 0x0a,   13 /* Public */,
      15,    1,  118,    2, 0x0a,   14 /* Public */,
      16,    0,  121,    2, 0x0a,   16 /* Public */,
      17,    0,  122,    2, 0x0a,   17 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPixmap,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Processing::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Processing.offsetsAndSizes,
    qt_meta_data_Processing,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Processing_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Processing, std::true_type>,
        // method 'brightUp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessLow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inverstion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPixmap, std::false_type>,
        // method 'verticalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'horizontalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sharpen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomIn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'leftRotate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rightRotate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessUpOpenCV'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessDownOpenCV'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'his'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'imageClear'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Processing::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Processing *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->brightUp(); break;
        case 1: _t->brightnessLow(); break;
        case 2: _t->inverstion((*reinterpret_cast< std::add_pointer_t<QPixmap>>(_a[1]))); break;
        case 3: _t->verticalFlip(); break;
        case 4: _t->horizontalFlip(); break;
        case 5: _t->sharpen(); break;
        case 6: _t->zoomIn(); break;
        case 7: _t->zoomOut(); break;
        case 8: _t->leftRotate(); break;
        case 9: _t->rightRotate(); break;
        case 10: _t->brightnessUpOpenCV(); break;
        case 11: _t->brightnessDownOpenCV(); break;
        case 12: _t->brightSlider((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->his(); break;
        case 14: _t->imageClear(); break;
        default: ;
        }
    }
}

const QMetaObject *Processing::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Processing::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Processing.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Processing::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
