#ifndef QDOWNLOADER_H
#define QDOWNLOADER_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFile>
#include <QStringList>

class QDownloader : public QObject
{
    Q_OBJECT

public:
    QDownloader(QObject *parent = nullptr);
    ~QDownloader();
    void setFile(QString fileURL);

private:
    QNetworkAccessManager *manager;
    QNetworkReply *reply;
    QFile *file;

private slots:
    void onDownloadProgress(qint64, qint64);
    void onFinished(QNetworkReply*);
    void onReadyRead();
    void onReplyFinished();
};
#endif // QDOWNLOADER_H
