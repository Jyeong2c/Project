#include "keyfeaturesform.h"
#include "ui_keyfeaturesform.h"

KeyFeaturesForm::KeyFeaturesForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::KeyFeaturesForm)
{
    ui->setupUi(this);

    ui->verticalSpacer->changeSize(10,10);
    ui->verticalSpacer_2->changeSize(10,10);

    ui->zoomInCheckBox->isChecked();
//    setDown (arg1) / isDown ()
}

KeyFeaturesForm::~KeyFeaturesForm()
{
    delete ui;
}

void KeyFeaturesForm::on_zoomInCheckBox_stateChanged(int arg1)
{

}

