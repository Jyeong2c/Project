#ifndef KEYFEATURESFORM_H
#define KEYFEATURESFORM_H

#include <QWidget>

namespace Ui {
class KeyFeaturesForm;
}

class KeyFeaturesForm : public QWidget
{
    Q_OBJECT

public:
    explicit KeyFeaturesForm(QWidget *parent = nullptr);
    ~KeyFeaturesForm();

private slots:
    void on_zoomInCheckBox_stateChanged(int arg1);

private:
    Ui::KeyFeaturesForm *ui;
};

#endif // KEYFEATURESFORM_H
