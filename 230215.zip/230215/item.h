#ifndef ITEM_H
#define ITEM_H

#include <QGraphicsItem>

class item : public QGraphicsItem
{
    Q_OBJECT
public:
    explicit item(QWidget *parent = nullptr);

signals:

};

#endif // ITEM_H
