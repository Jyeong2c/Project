#ifndef LAYOUT_H
#define LAYOUT_H

#include <QWidget>

class QGraphicsScene;
class QGraphicsView;

class Layout : public QWidget
{
    Q_OBJECT
public:
    explicit Layout(QWidget *parent = nullptr);

public slots:
    void brightUp();
    void brightnessLow();
    void inverstion();
    void verticalFlip();
    void horizontalFlip();
    void mono();
//    void bright();
    void dark();


private:
    void gridLayout();
    QImage * image;
    QGraphicsView *grid1;
    QGraphicsView *grid2;
    QGraphicsScene* scene;

    int intensity=0;

signals:

};

#endif // LAYOUT_H
