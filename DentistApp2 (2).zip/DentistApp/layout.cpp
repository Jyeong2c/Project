#include "layout.h"

//#include <opencv2/opencv.hpp>

//using namespace cv;
//using namespace std;

#include <QGridLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QPixmap>
#include <QImage>
#include <QPixelFormat>

#define LIMIT_UBYTE(n) ((n)>UCHAR_MAX)?UCHAR_MAX:((n)<0)?0:(n)

Layout::Layout(QWidget *parent)
    : QWidget{parent}
{
    gridLayout();

    image = new QImage();
    //    imgSize->load("C:/Users/KOSA/Desktop/HTML Canvas/HTML Canvas/orthopan.jpg");
    //    image->load("C:/Users/KOSA/Desktop/Qt/ㅇㅁㅈ.jpg");

    image->load("C:/Users/KOSA/Desktop/Qt/tooth.png");
    //    if(QColorConstants::Gray == true){
    //        QImgae *temp  = new QImgae(data,width,height,QImage::Format_RGB888);
    //    }

    QPixmap buf = QPixmap::fromImage(*image);
    buf = buf.scaled(image->width(), image->height());


    scene = new QGraphicsScene;
    scene->addPixmap(buf);
    grid1->setScene(scene);

    //grid1->setBackgroundBrush(Qt::black);
}

/* 2 X 2 Grid */
void Layout::gridLayout()
{
    //QWidget *window = new QWidget;

    grid1 = new QGraphicsView;
    grid2 = new QGraphicsView;
    QGraphicsView *grid3 = new QGraphicsView;
    QGraphicsView *grid4 = new QGraphicsView;

    //    QGridLayout *layout = new QGridLayout(this);
    //    layout->addWidget(grid1, 0, 0);                   // QWidget*, row, column->addSpacing(5);
    //    layout->addWidget(grid2, 0, 1);
    //    layout->addWidget(grid3, 1, 0);
    //    layout->addWidget(grid4, 1, 1);

    QHBoxLayout *lay1 = new QHBoxLayout;
    lay1->addWidget(grid1);
    lay1->addSpacing(5);
    lay1->addWidget(grid2);

    QHBoxLayout *lay2 = new QHBoxLayout;
    lay2->addWidget(grid3);
    lay2->addSpacing(5);
    lay2->addWidget(grid4);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addLayout(lay1);
    layout->addSpacing(5);
    layout->addLayout(lay2);

    //layout->addWidget(bigButton, 2, 0, 1, 2);
}

//void Layout::bright()
//{
//    int sizeX = 512;
//    int sizeY = 512;
//    int color = 0;

//    QImage image = QImage(sizeX, sizeY, QImage::Format_RGB32);

//    for(int row=0; row<sizeY; row++)
//    {
//        for(int column=0; column<sizeX; column++)
//        {
//            image.setPixel(column, row, qRgb(color, color, color));
//            //image.setPixel(i, j, 100);
//        }

//        //        color++;
//    }

//    QGraphicsScene *graphic = new QGraphicsScene(this);

//    graphic->addPixmap(QPixmap::fromImage(image));

//    grid1->setScene(graphic);
//}



void Layout::brightUp()
{
    intensity+=5;
    //    int tmp;

    QImage image_to_display =  QImage(*image);

    for(int x = 0; x < image_to_display.width(); ++x){
        for(int y = 0 ; y < image_to_display.height(); ++y) {

            const QRgb rgb = image->pixel(x, y);
            const double r =LIMIT_UBYTE(qRed(rgb)   + intensity);
            const double g =LIMIT_UBYTE(qGreen(rgb) + intensity);
            const double b =LIMIT_UBYTE(qBlue(rgb)  + intensity);

            image_to_display.setPixelColor(x, y,QColor(r,g,b));
        }
    }
    scene = new QGraphicsScene;


    QPixmap buf = QPixmap::fromImage(image_to_display);
    scene->addPixmap(buf);
    grid1->setScene(scene);
    scene->addPixmap(buf.scaled(image->width(),image->height(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
}

void Layout::brightnessLow()
{
    intensity-=5;
    //    int tmp;
    QImage image_to_display =  QImage(*image);

    for(int x = 0; x < image_to_display.width(); ++x)
        for(int y = 0 ; y < image_to_display.height(); ++y) {
            const QRgb rgb = image->pixel(x, y);
            //            if(rgb >125){
            //                tmp = (image->pixel(x,y)-125) * 0.3;
            //                tmp = image->pixel(x,y) + tmp;
            //            }
            //            else{
            //                tmp = (125 - image->pixel(x,y)) * 0.3;
            //                tmp = image->pixel(x,y) - tmp;
            //            }
            //            if(rgb >0 ){
            const double r =LIMIT_UBYTE(qRed(rgb)   + intensity);
            const double g =LIMIT_UBYTE(qGreen(rgb) + intensity);
            const double b =LIMIT_UBYTE(qBlue(rgb)  + intensity);

            image_to_display.setPixelColor(x, y,QColor(r,g,b));

            //            }
        }
    scene = new QGraphicsScene;

    QPixmap buf = QPixmap::fromImage(image_to_display);
    scene->addPixmap(buf);
    grid1->setScene(scene);
    scene->addPixmap(buf);
}

void Layout::inverstion()
{

    image->invertPixels();

    scene = new QGraphicsScene;

    QPixmap buf = QPixmap::fromImage(*image);
    scene->addPixmap(buf);
    grid1->setScene(scene);
    scene->addPixmap(buf);
}

void Layout::verticalFlip()
{

    image->mirror(true,false);

    scene = new QGraphicsScene;

    QPixmap buf = QPixmap::fromImage(*image);
    scene->addPixmap(buf);
    grid1->setScene(scene);
    scene->addPixmap(buf);
}
void Layout::horizontalFlip()
{

    image->mirror(false,true);

    scene = new QGraphicsScene;

    QPixmap buf = QPixmap::fromImage(*image);
    scene->addPixmap(buf);
    grid1->setScene(scene);
    //    scene->addPixmap(buf);
    scene->addPixmap(buf.scaled(image->width(),image->height(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
}

void Layout::mono()
{
//    //    image->convertTo(QImage::NImageFormats,Qt::AutoColor);

//    //    scene = new QGraphicsScene;

//    //    QPixmap buf = QPixmap::fromImage(*image);
//    //    scene->addPixmap(buf);
//    //    grid1->setScene(scene);
//    //    scene->addPixmap(buf.scaled(image->width(),image->height(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation));

//    intensity -= -125*0.3;
//    //    int tmp;
//    QImage image_to_display =  QImage(*image);

//    for(int x = 0; x < image_to_display.width(); ++x)
//        for(int y = 0 ; y < image_to_display.height(); ++y) {
//            const QRgb rgb = image->pixel(x, y);
//            //            if(rgb >125){
//            //                tmp = (image->pixel(x,y)-125) * 0.3;
//            //                tmp = image->pixel(x,y) + tmp;
//            //            }
//            //            else{
//            //                tmp = (125 - image->pixel(x,y)) * 0.3;
//            //                tmp = image->pixel(x,y) - tmp;
//            //            }
//            //            if(rgb >0 ){
//            if( rgb> 125){
//                const double r =LIMIT_UBYTE(qRed(rgb)   + intensity);
//                const double g =LIMIT_UBYTE(qGreen(rgb) + intensity);
//                const double b =LIMIT_UBYTE(qBlue(rgb)  + intensity);
//            }
//            else{
//                 r =LIMIT_UBYTE(qRed(rgb)   *0.3);
//                 g =LIMIT_UBYTE(qGreen(rgb) *0.3);
//                 b =LIMIT_UBYTE(qBlue(rgb)  *0.3);
//            }
//            image_to_display.setPixelColor(x, y,QColor(r,g,b));

//            //            }
//        }
//    scene = new QGraphicsScene;

//    QPixmap buf = QPixmap::fromImage(image_to_display);
//    scene->addPixmap(buf);
//    grid1->setScene(scene);
//    scene->addPixmap(buf);
}

void Layout::dark()
{
    int tmp;
    for(int i=0; i<image->height(); i++){
            for(int j=0; j<image->width(); j++){
                if(image->pixel(x(),y())> 125){
                    tmp = (image->pixel(x(),y()) - 125) * 0.3;
                    tmp = image->pixel(x(),y()) + tmp;
                }
                else{
                    tmp = (125 - image->pixel(x(),y())) * 0.3;
                    tmp = image->pixel(x(),y()) - tmp;
                }
            }
    }

}


//QImage *image = new QImage(ui->listWidget->currentItem()->statusTip());

//for(int x = 0; x < image->width(); ++x)
//        for(int y = 0 ; y < image->height(); ++y) {
//            const QRgb rgb = image->pixel(x, y);
//            const double r = LIMIT_UBYTE(qRed(rgb) + value);
//            const double g = LIMIT_UBYTE(qGreen(rgb) + value);
//            const double b = LIMIT_UBYTE(qBlue(rgb) + value);
//            image->setPixelColor(x, y,
//                                 QColor(
//                                     r,
//                                     g,
//                                     b));
//        }

//QPixmap buf = QPixmap::fromImage(image_Histogram);
//imageView->setScene(imageView->graphicsScene);
//imageView->graphicsScene->addPixmap(buf.scaled(imageView->width(), imageView->height(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));


