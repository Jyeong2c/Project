/****************************************************************************
** Meta object code from reading C++ file 'layout.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DentistApp/layout.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layout.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Layout_t {
    uint offsetsAndSizes[18];
    char stringdata0[7];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[11];
    char stringdata5[13];
    char stringdata6[15];
    char stringdata7[5];
    char stringdata8[5];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Layout_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Layout_t qt_meta_stringdata_Layout = {
    {
        QT_MOC_LITERAL(0, 6),  // "Layout"
        QT_MOC_LITERAL(7, 8),  // "brightUp"
        QT_MOC_LITERAL(16, 0),  // ""
        QT_MOC_LITERAL(17, 13),  // "brightnessLow"
        QT_MOC_LITERAL(31, 10),  // "inverstion"
        QT_MOC_LITERAL(42, 12),  // "verticalFlip"
        QT_MOC_LITERAL(55, 14),  // "horizontalFlip"
        QT_MOC_LITERAL(70, 4),  // "mono"
        QT_MOC_LITERAL(75, 4)   // "dark"
    },
    "Layout",
    "brightUp",
    "",
    "brightnessLow",
    "inverstion",
    "verticalFlip",
    "horizontalFlip",
    "mono",
    "dark"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Layout[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   56,    2, 0x0a,    1 /* Public */,
       3,    0,   57,    2, 0x0a,    2 /* Public */,
       4,    0,   58,    2, 0x0a,    3 /* Public */,
       5,    0,   59,    2, 0x0a,    4 /* Public */,
       6,    0,   60,    2, 0x0a,    5 /* Public */,
       7,    0,   61,    2, 0x0a,    6 /* Public */,
       8,    0,   62,    2, 0x0a,    7 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Layout::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Layout.offsetsAndSizes,
    qt_meta_data_Layout,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Layout_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Layout, std::true_type>,
        // method 'brightUp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'brightnessLow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inverstion'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'verticalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'horizontalFlip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'mono'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dark'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Layout::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Layout *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->brightUp(); break;
        case 1: _t->brightnessLow(); break;
        case 2: _t->inverstion(); break;
        case 3: _t->verticalFlip(); break;
        case 4: _t->horizontalFlip(); break;
        case 5: _t->mono(); break;
        case 6: _t->dark(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *Layout::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Layout::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Layout.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Layout::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
