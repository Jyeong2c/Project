/********************************************************************************
** Form generated from reading UI file 'chetting.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHETTING_H
#define UI_CHETTING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Chetting
{
public:
    QVBoxLayout *verticalLayout_4;
    QLabel *serverstatus;
    QHBoxLayout *horizontalLayout;
    QLineEdit *manager;
    QLineEdit *ipAddress;
    QLineEdit *portNumber;
    QPushButton *connectButton;
    QVBoxLayout *verticalLayout_3;
    QTextEdit *textmessage;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *inputEdit;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *FileSendButton;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QPushButton *sendButton;
    QPushButton *cacelButton;

    void setupUi(QWidget *Chetting)
    {
        if (Chetting->objectName().isEmpty())
            Chetting->setObjectName(QString::fromUtf8("Chetting"));
        Chetting->resize(468, 346);
        verticalLayout_4 = new QVBoxLayout(Chetting);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        serverstatus = new QLabel(Chetting);
        serverstatus->setObjectName(QString::fromUtf8("serverstatus"));

        verticalLayout_4->addWidget(serverstatus);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        manager = new QLineEdit(Chetting);
        manager->setObjectName(QString::fromUtf8("manager"));
        manager->setReadOnly(false);

        horizontalLayout->addWidget(manager);

        ipAddress = new QLineEdit(Chetting);
        ipAddress->setObjectName(QString::fromUtf8("ipAddress"));

        horizontalLayout->addWidget(ipAddress);

        portNumber = new QLineEdit(Chetting);
        portNumber->setObjectName(QString::fromUtf8("portNumber"));

        horizontalLayout->addWidget(portNumber);

        connectButton = new QPushButton(Chetting);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));

        horizontalLayout->addWidget(connectButton);


        verticalLayout_4->addLayout(horizontalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        textmessage = new QTextEdit(Chetting);
        textmessage->setObjectName(QString::fromUtf8("textmessage"));

        verticalLayout_3->addWidget(textmessage);


        verticalLayout_4->addLayout(verticalLayout_3);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        inputEdit = new QLineEdit(Chetting);
        inputEdit->setObjectName(QString::fromUtf8("inputEdit"));

        verticalLayout_2->addWidget(inputEdit);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        FileSendButton = new QPushButton(Chetting);
        FileSendButton->setObjectName(QString::fromUtf8("FileSendButton"));

        horizontalLayout_2->addWidget(FileSendButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        verticalLayout_2->addLayout(horizontalLayout_2);


        horizontalLayout_3->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        sendButton = new QPushButton(Chetting);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));

        verticalLayout->addWidget(sendButton);

        cacelButton = new QPushButton(Chetting);
        cacelButton->setObjectName(QString::fromUtf8("cacelButton"));

        verticalLayout->addWidget(cacelButton);


        horizontalLayout_3->addLayout(verticalLayout);


        verticalLayout_4->addLayout(horizontalLayout_3);


        retranslateUi(Chetting);

        QMetaObject::connectSlotsByName(Chetting);
    } // setupUi

    void retranslateUi(QWidget *Chetting)
    {
        Chetting->setWindowTitle(QCoreApplication::translate("Chetting", "Form", nullptr));
        serverstatus->setText(QCoreApplication::translate("Chetting", "only manager chetting client", nullptr));
        manager->setText(QCoreApplication::translate("Chetting", "manager", nullptr));
        connectButton->setText(QCoreApplication::translate("Chetting", "connect", nullptr));
        FileSendButton->setText(QCoreApplication::translate("Chetting", "Send File", nullptr));
        sendButton->setText(QCoreApplication::translate("Chetting", "sendButton", nullptr));
        cacelButton->setText(QCoreApplication::translate("Chetting", "clearButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Chetting: public Ui_Chetting {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHETTING_H
