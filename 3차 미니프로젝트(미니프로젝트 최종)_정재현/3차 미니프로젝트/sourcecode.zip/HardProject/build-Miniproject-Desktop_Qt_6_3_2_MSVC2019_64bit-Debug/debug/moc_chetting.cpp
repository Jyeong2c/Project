/****************************************************************************
** Meta object code from reading C++ file 'chetting.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DataBaseQt-master/chetting.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chetting.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Chetting_t {
    uint offsetsAndSizes[26];
    char stringdata0[9];
    char stringdata1[10];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[12];
    char stringdata5[9];
    char stringdata6[11];
    char stringdata7[9];
    char stringdata8[13];
    char stringdata9[13];
    char stringdata10[6];
    char stringdata11[9];
    char stringdata12[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Chetting_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_Chetting_t qt_meta_stringdata_Chetting = {
    {
        QT_MOC_LITERAL(0, 8),  // "Chetting"
        QT_MOC_LITERAL(9, 9),  // "TCPSignal"
        QT_MOC_LITERAL(19, 0),  // ""
        QT_MOC_LITERAL(20, 12),  // "signalClient"
        QT_MOC_LITERAL(33, 11),  // "receiveData"
        QT_MOC_LITERAL(45, 8),  // "sendData"
        QT_MOC_LITERAL(54, 10),  // "disconnect"
        QT_MOC_LITERAL(65, 8),  // "sendFile"
        QT_MOC_LITERAL(74, 12),  // "sendProtocol"
        QT_MOC_LITERAL(87, 12),  // "StatusOfChat"
        QT_MOC_LITERAL(100, 5),  // "char*"
        QT_MOC_LITERAL(106, 8),  // "goOnSend"
        QT_MOC_LITERAL(115, 20)   // "receiveTCPClientName"
    },
    "Chetting",
    "TCPSignal",
    "",
    "signalClient",
    "receiveData",
    "sendData",
    "disconnect",
    "sendFile",
    "sendProtocol",
    "StatusOfChat",
    "char*",
    "goOnSend",
    "receiveTCPClientName"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Chetting[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   74,    2, 0x06,    1 /* Public */,
       3,    2,   79,    2, 0x06,    4 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,   84,    2, 0x08,    7 /* Private */,
       5,    0,   85,    2, 0x08,    8 /* Private */,
       6,    0,   86,    2, 0x08,    9 /* Private */,
       7,    0,   87,    2, 0x08,   10 /* Private */,
       8,    3,   88,    2, 0x08,   11 /* Private */,
       8,    2,   95,    2, 0x28,   15 /* Private | MethodCloned */,
      11,    1,  100,    2, 0x08,   18 /* Private */,
      12,    1,  103,    2, 0x08,   20 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 10, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 10,    2,    2,
    QMetaType::Void, QMetaType::LongLong,    2,
    QMetaType::Void, QMetaType::QString,    2,

       0        // eod
};

void Chetting::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Chetting *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->TCPSignal((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 1: _t->signalClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->receiveData(); break;
        case 3: _t->sendData(); break;
        case 4: _t->disconnect(); break;
        case 5: _t->sendFile(); break;
        case 6: _t->sendProtocol((*reinterpret_cast< std::add_pointer_t<StatusOfChat>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<char*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 7: _t->sendProtocol((*reinterpret_cast< std::add_pointer_t<StatusOfChat>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<char*>>(_a[2]))); break;
        case 8: _t->goOnSend((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 9: _t->receiveTCPClientName((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Chetting::*)(int , QString );
            if (_t _q_method = &Chetting::TCPSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Chetting::*)(int , QString );
            if (_t _q_method = &Chetting::signalClient; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject Chetting::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Chetting.offsetsAndSizes,
    qt_meta_data_Chetting,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Chetting_t
, QtPrivate::TypeAndForceComplete<Chetting, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<StatusOfChat, std::false_type>, QtPrivate::TypeAndForceComplete<char *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<StatusOfChat, std::false_type>, QtPrivate::TypeAndForceComplete<char *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<qint64, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>


>,
    nullptr
} };


const QMetaObject *Chetting::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Chetting::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Chetting.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Chetting::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Chetting::TCPSignal(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Chetting::signalClient(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
