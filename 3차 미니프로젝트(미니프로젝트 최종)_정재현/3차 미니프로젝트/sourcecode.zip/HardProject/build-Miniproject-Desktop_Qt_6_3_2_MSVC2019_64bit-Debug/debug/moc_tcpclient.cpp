/****************************************************************************
** Meta object code from reading C++ file 'tcpclient.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DataBaseQt-master/tcpclient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tcpclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TCPClient_t {
    uint offsetsAndSizes[26];
    char stringdata0[10];
    char stringdata1[12];
    char stringdata2[1];
    char stringdata3[12];
    char stringdata4[9];
    char stringdata5[11];
    char stringdata6[13];
    char stringdata7[12];
    char stringdata8[6];
    char stringdata9[9];
    char stringdata10[9];
    char stringdata11[12];
    char stringdata12[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_TCPClient_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_TCPClient_t qt_meta_stringdata_TCPClient = {
    {
        QT_MOC_LITERAL(0, 9),  // "TCPClient"
        QT_MOC_LITERAL(10, 11),  // "compareName"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 11),  // "receiveData"
        QT_MOC_LITERAL(35, 8),  // "sendData"
        QT_MOC_LITERAL(44, 10),  // "disconnect"
        QT_MOC_LITERAL(55, 12),  // "sendProtocol"
        QT_MOC_LITERAL(68, 11),  // "Client_Chat"
        QT_MOC_LITERAL(80, 5),  // "char*"
        QT_MOC_LITERAL(86, 8),  // "sendFile"
        QT_MOC_LITERAL(95, 8),  // "goOnSend"
        QT_MOC_LITERAL(104, 11),  // "filereceive"
        QT_MOC_LITERAL(116, 13)   // "receiveSignal"
    },
    "TCPClient",
    "compareName",
    "",
    "receiveData",
    "sendData",
    "disconnect",
    "sendProtocol",
    "Client_Chat",
    "char*",
    "sendFile",
    "goOnSend",
    "filereceive",
    "receiveSignal"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TCPClient[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   74,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   77,    2, 0x08,    3 /* Private */,
       4,    0,   78,    2, 0x08,    4 /* Private */,
       5,    0,   79,    2, 0x08,    5 /* Private */,
       6,    3,   80,    2, 0x08,    6 /* Private */,
       6,    2,   87,    2, 0x28,   10 /* Private | MethodCloned */,
       9,    0,   92,    2, 0x08,   13 /* Private */,
      10,    1,   93,    2, 0x08,   14 /* Private */,
      11,    0,   96,    2, 0x08,   16 /* Private */,
      12,    1,   97,    2, 0x08,   17 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 8, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 8,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

void TCPClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TCPClient *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->compareName((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->receiveData(); break;
        case 2: _t->sendData(); break;
        case 3: _t->disconnect(); break;
        case 4: _t->sendProtocol((*reinterpret_cast< std::add_pointer_t<Client_Chat>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<char*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 5: _t->sendProtocol((*reinterpret_cast< std::add_pointer_t<Client_Chat>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<char*>>(_a[2]))); break;
        case 6: _t->sendFile(); break;
        case 7: _t->goOnSend((*reinterpret_cast< std::add_pointer_t<qint64>>(_a[1]))); break;
        case 8: _t->filereceive(); break;
        case 9: _t->receiveSignal((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TCPClient::*)(QString );
            if (_t _q_method = &TCPClient::compareName; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject TCPClient::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_TCPClient.offsetsAndSizes,
    qt_meta_data_TCPClient,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_TCPClient_t
, QtPrivate::TypeAndForceComplete<TCPClient, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Client_Chat, std::false_type>, QtPrivate::TypeAndForceComplete<char *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Client_Chat, std::false_type>, QtPrivate::TypeAndForceComplete<char *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<qint64, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *TCPClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TCPClient::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TCPClient.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TCPClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void TCPClient::compareName(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
