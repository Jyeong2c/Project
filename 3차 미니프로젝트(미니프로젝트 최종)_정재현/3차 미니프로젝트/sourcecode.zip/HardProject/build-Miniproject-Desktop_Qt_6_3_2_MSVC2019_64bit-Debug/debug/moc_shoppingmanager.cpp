/****************************************************************************
** Meta object code from reading C++ file 'shoppingmanager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DataBaseQt-master/shoppingmanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'shoppingmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ShoppingManager_t {
    uint offsetsAndSizes[34];
    char stringdata0[16];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[13];
    char stringdata5[4];
    char stringdata6[13];
    char stringdata7[14];
    char stringdata8[6];
    char stringdata9[23];
    char stringdata10[24];
    char stringdata11[24];
    char stringdata12[24];
    char stringdata13[21];
    char stringdata14[12];
    char stringdata15[6];
    char stringdata16[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_ShoppingManager_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_ShoppingManager_t qt_meta_stringdata_ShoppingManager = {
    {
        QT_MOC_LITERAL(0, 15),  // "ShoppingManager"
        QT_MOC_LITERAL(16, 15),  // "showContextMenu"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 10),  // "removeItem"
        QT_MOC_LITERAL(44, 12),  // "CreceiveData"
        QT_MOC_LITERAL(57, 3),  // "str"
        QT_MOC_LITERAL(61, 12),  // "PreceiveData"
        QT_MOC_LITERAL(74, 13),  // "PreceivePrice"
        QT_MOC_LITERAL(88, 5),  // "price"
        QT_MOC_LITERAL(94, 22),  // "on_InputButton_clicked"
        QT_MOC_LITERAL(117, 23),  // "on_CancelButton_clicked"
        QT_MOC_LITERAL(141, 23),  // "on_ModifyButton_clicked"
        QT_MOC_LITERAL(165, 23),  // "on_SearchButton_clicked"
        QT_MOC_LITERAL(189, 20),  // "on_tableView_clicked"
        QT_MOC_LITERAL(210, 11),  // "QModelIndex"
        QT_MOC_LITERAL(222, 5),  // "index"
        QT_MOC_LITERAL(228, 23)   // "on_RecentButton_clicked"
    },
    "ShoppingManager",
    "showContextMenu",
    "",
    "removeItem",
    "CreceiveData",
    "str",
    "PreceiveData",
    "PreceivePrice",
    "price",
    "on_InputButton_clicked",
    "on_CancelButton_clicked",
    "on_ModifyButton_clicked",
    "on_SearchButton_clicked",
    "on_tableView_clicked",
    "QModelIndex",
    "index",
    "on_RecentButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ShoppingManager[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   80,    2, 0x0a,    1 /* Public */,
       3,    0,   83,    2, 0x0a,    3 /* Public */,
       4,    1,   84,    2, 0x0a,    4 /* Public */,
       6,    1,   87,    2, 0x0a,    6 /* Public */,
       7,    1,   90,    2, 0x0a,    8 /* Public */,
       9,    0,   93,    2, 0x0a,   10 /* Public */,
      10,    0,   94,    2, 0x0a,   11 /* Public */,
      11,    0,   95,    2, 0x0a,   12 /* Public */,
      12,    0,   96,    2, 0x0a,   13 /* Public */,
      13,    1,   97,    2, 0x0a,   14 /* Public */,
      16,    0,  100,    2, 0x0a,   16 /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void,

       0        // eod
};

void ShoppingManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ShoppingManager *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showContextMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 1: _t->removeItem(); break;
        case 2: _t->CreceiveData((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->PreceiveData((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->PreceivePrice((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->on_InputButton_clicked(); break;
        case 6: _t->on_CancelButton_clicked(); break;
        case 7: _t->on_ModifyButton_clicked(); break;
        case 8: _t->on_SearchButton_clicked(); break;
        case 9: _t->on_tableView_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 10: _t->on_RecentButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject ShoppingManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ShoppingManager.offsetsAndSizes,
    qt_meta_data_ShoppingManager,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_ShoppingManager_t
, QtPrivate::TypeAndForceComplete<ShoppingManager, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *ShoppingManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ShoppingManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ShoppingManager.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ShoppingManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
