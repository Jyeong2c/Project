/********************************************************************************
** Form generated from reading UI file 'clientmanager.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTMANAGER_H
#define UI_CLIENTMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClientManager
{
public:
    QHBoxLayout *horizontalLayout_6;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *Inputpage;
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *CIDLineEdit;
    QLineEdit *CPhoneLineEdit;
    QLineEdit *CEmailLineEdit;
    QLineEdit *CNameLineEdit;
    QLabel *label_5;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_7;
    QLineEdit *RemoveLineEdit;
    QPushButton *removeButton;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *InputButton;
    QPushButton *CancelButton;
    QPushButton *ModifyButton;
    QWidget *SearchBox;
    QVBoxLayout *verticalLayout_2;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout_4;
    QComboBox *SearchComboBox;
    QLineEdit *SearchLineEdit;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *TBpushButton;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *ClientManager)
    {
        if (ClientManager->objectName().isEmpty())
            ClientManager->setObjectName(QString::fromUtf8("ClientManager"));
        ClientManager->resize(629, 446);
        horizontalLayout_6 = new QHBoxLayout(ClientManager);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        splitter = new QSplitter(ClientManager);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        groupBox_2 = new QGroupBox(layoutWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        horizontalLayout = new QHBoxLayout(groupBox_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        tableView = new QTableView(groupBox_2);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

        horizontalLayout->addWidget(tableView);


        verticalLayout_3->addWidget(groupBox_2);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        Inputpage = new QWidget();
        Inputpage->setObjectName(QString::fromUtf8("Inputpage"));
        Inputpage->setGeometry(QRect(0, 0, 302, 386));
        verticalLayout = new QVBoxLayout(Inputpage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(Inputpage);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        label_2 = new QLabel(Inputpage);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        label_3 = new QLabel(Inputpage);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        label_4 = new QLabel(Inputpage);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        CIDLineEdit = new QLineEdit(Inputpage);
        CIDLineEdit->setObjectName(QString::fromUtf8("CIDLineEdit"));
        CIDLineEdit->setReadOnly(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, CIDLineEdit);

        CPhoneLineEdit = new QLineEdit(Inputpage);
        CPhoneLineEdit->setObjectName(QString::fromUtf8("CPhoneLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, CPhoneLineEdit);

        CEmailLineEdit = new QLineEdit(Inputpage);
        CEmailLineEdit->setObjectName(QString::fromUtf8("CEmailLineEdit"));

        formLayout->setWidget(3, QFormLayout::FieldRole, CEmailLineEdit);

        CNameLineEdit = new QLineEdit(Inputpage);
        CNameLineEdit->setObjectName(QString::fromUtf8("CNameLineEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, CNameLineEdit);


        verticalLayout->addLayout(formLayout);

        label_5 = new QLabel(Inputpage);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_5);

        verticalSpacer = new QSpacerItem(20, 323, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        RemoveLineEdit = new QLineEdit(Inputpage);
        RemoveLineEdit->setObjectName(QString::fromUtf8("RemoveLineEdit"));

        horizontalLayout_7->addWidget(RemoveLineEdit);

        removeButton = new QPushButton(Inputpage);
        removeButton->setObjectName(QString::fromUtf8("removeButton"));

        horizontalLayout_7->addWidget(removeButton);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        InputButton = new QPushButton(Inputpage);
        InputButton->setObjectName(QString::fromUtf8("InputButton"));

        horizontalLayout_2->addWidget(InputButton);

        CancelButton = new QPushButton(Inputpage);
        CancelButton->setObjectName(QString::fromUtf8("CancelButton"));

        horizontalLayout_2->addWidget(CancelButton);

        ModifyButton = new QPushButton(Inputpage);
        ModifyButton->setObjectName(QString::fromUtf8("ModifyButton"));

        horizontalLayout_2->addWidget(ModifyButton);


        verticalLayout->addLayout(horizontalLayout_2);

        toolBox->addItem(Inputpage, QString::fromUtf8("Input"));
        SearchBox = new QWidget();
        SearchBox->setObjectName(QString::fromUtf8("SearchBox"));
        SearchBox->setGeometry(QRect(0, 0, 302, 386));
        verticalLayout_2 = new QVBoxLayout(SearchBox);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        searchTableView = new QTableView(SearchBox);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->verticalHeader()->setVisible(false);
        searchTableView->verticalHeader()->setProperty("showSortIndicator", QVariant(false));

        verticalLayout_2->addWidget(searchTableView);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        SearchComboBox = new QComboBox(SearchBox);
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->setObjectName(QString::fromUtf8("SearchComboBox"));

        horizontalLayout_4->addWidget(SearchComboBox);

        SearchLineEdit = new QLineEdit(SearchBox);
        SearchLineEdit->setObjectName(QString::fromUtf8("SearchLineEdit"));

        horizontalLayout_4->addWidget(SearchLineEdit);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        TBpushButton = new QPushButton(SearchBox);
        TBpushButton->setObjectName(QString::fromUtf8("TBpushButton"));

        horizontalLayout_3->addWidget(TBpushButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_3);

        toolBox->addItem(SearchBox, QString::fromUtf8("Search"));
        splitter->addWidget(toolBox);

        horizontalLayout_6->addWidget(splitter);

        QWidget::setTabOrder(tableView, CIDLineEdit);
        QWidget::setTabOrder(CIDLineEdit, CNameLineEdit);
        QWidget::setTabOrder(CNameLineEdit, CPhoneLineEdit);
        QWidget::setTabOrder(CPhoneLineEdit, CEmailLineEdit);
        QWidget::setTabOrder(CEmailLineEdit, RemoveLineEdit);
        QWidget::setTabOrder(RemoveLineEdit, removeButton);
        QWidget::setTabOrder(removeButton, InputButton);
        QWidget::setTabOrder(InputButton, CancelButton);
        QWidget::setTabOrder(CancelButton, ModifyButton);
        QWidget::setTabOrder(ModifyButton, SearchComboBox);
        QWidget::setTabOrder(SearchComboBox, SearchLineEdit);

        retranslateUi(ClientManager);

        toolBox->setCurrentIndex(1);
        SearchComboBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ClientManager);
    } // setupUi

    void retranslateUi(QWidget *ClientManager)
    {
        ClientManager->setWindowTitle(QCoreApplication::translate("ClientManager", "Form", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("ClientManager", "ClientDB", nullptr));
        label->setText(QCoreApplication::translate("ClientManager", "ClientID", nullptr));
        label_2->setText(QCoreApplication::translate("ClientManager", "ClientName", nullptr));
        label_3->setText(QCoreApplication::translate("ClientManager", "ClientPhone", nullptr));
        label_4->setText(QCoreApplication::translate("ClientManager", "ClientEmail", nullptr));
        CPhoneLineEdit->setInputMask(QCoreApplication::translate("ClientManager", "999-0000-9999", nullptr));
        label_5->setText(QCoreApplication::translate("ClientManager", "\354\225\204\354\235\264\353\224\224\353\245\274 \354\235\270\355\222\213 \355\225\240 \354\213\234 \355\225\230\353\213\250\354\235\230 Recent\353\245\274 \355\201\264\353\246\255\355\233\204\n"
"\354\235\270\355\222\213 \353\215\260\354\235\264\355\204\260\353\245\274 \355\225\264\354\244\230\354\225\274 \353\215\260\354\235\264\355\204\260\352\260\200 \354\236\205\353\240\245\353\220\234\353\213\244", nullptr));
        removeButton->setText(QCoreApplication::translate("ClientManager", "Recent", nullptr));
        InputButton->setText(QCoreApplication::translate("ClientManager", "Input", nullptr));
        CancelButton->setText(QCoreApplication::translate("ClientManager", "Cancel", nullptr));
        ModifyButton->setText(QCoreApplication::translate("ClientManager", "Modify", nullptr));
        toolBox->setItemText(toolBox->indexOf(Inputpage), QCoreApplication::translate("ClientManager", "Input", nullptr));
        SearchComboBox->setItemText(0, QCoreApplication::translate("ClientManager", "ClientID", nullptr));
        SearchComboBox->setItemText(1, QCoreApplication::translate("ClientManager", "ClientName", nullptr));
        SearchComboBox->setItemText(2, QCoreApplication::translate("ClientManager", "ClientPhone", nullptr));
        SearchComboBox->setItemText(3, QCoreApplication::translate("ClientManager", "ClientEmail", nullptr));

        TBpushButton->setText(QCoreApplication::translate("ClientManager", "Search", nullptr));
        toolBox->setItemText(toolBox->indexOf(SearchBox), QCoreApplication::translate("ClientManager", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ClientManager: public Ui_ClientManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTMANAGER_H
