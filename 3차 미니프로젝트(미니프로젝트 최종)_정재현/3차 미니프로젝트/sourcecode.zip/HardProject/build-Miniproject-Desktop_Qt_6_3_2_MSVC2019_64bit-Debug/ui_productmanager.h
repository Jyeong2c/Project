/********************************************************************************
** Form generated from reading UI file 'productmanager.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTMANAGER_H
#define UI_PRODUCTMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProductManager
{
public:
    QHBoxLayout *horizontalLayout_2;
    QSplitter *splitter;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *InputPage;
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *PIDLineEdit;
    QLineEdit *PNameLineEdit;
    QLineEdit *PCompanyLineEdit;
    QLineEdit *PPriceLineEdit;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *RecentLineEdit;
    QPushButton *RecentButton;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *InputButton;
    QPushButton *CancelButton;
    QPushButton *ModifyButton;
    QSpacerItem *horizontalSpacer_2;
    QWidget *SearchPage;
    QVBoxLayout *verticalLayout_2;
    QTableView *TBSearchView;
    QHBoxLayout *horizontalLayout_4;
    QComboBox *SearchComboBox;
    QLineEdit *SearchLineEdit;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *Search;
    QSpacerItem *horizontalSpacer_4;

    void setupUi(QWidget *ProductManager)
    {
        if (ProductManager->objectName().isEmpty())
            ProductManager->setObjectName(QString::fromUtf8("ProductManager"));
        ProductManager->resize(579, 376);
        horizontalLayout_2 = new QHBoxLayout(ProductManager);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        splitter = new QSplitter(ProductManager);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        tableView = new QTableView(splitter);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        splitter->addWidget(tableView);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        InputPage = new QWidget();
        InputPage->setObjectName(QString::fromUtf8("InputPage"));
        InputPage->setGeometry(QRect(0, 0, 326, 316));
        verticalLayout = new QVBoxLayout(InputPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(InputPage);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        label_2 = new QLabel(InputPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        label_3 = new QLabel(InputPage);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        label_4 = new QLabel(InputPage);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        PIDLineEdit = new QLineEdit(InputPage);
        PIDLineEdit->setObjectName(QString::fromUtf8("PIDLineEdit"));
        PIDLineEdit->setReadOnly(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, PIDLineEdit);

        PNameLineEdit = new QLineEdit(InputPage);
        PNameLineEdit->setObjectName(QString::fromUtf8("PNameLineEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, PNameLineEdit);

        PCompanyLineEdit = new QLineEdit(InputPage);
        PCompanyLineEdit->setObjectName(QString::fromUtf8("PCompanyLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, PCompanyLineEdit);

        PPriceLineEdit = new QLineEdit(InputPage);
        PPriceLineEdit->setObjectName(QString::fromUtf8("PPriceLineEdit"));

        formLayout->setWidget(3, QFormLayout::FieldRole, PPriceLineEdit);


        verticalLayout->addLayout(formLayout);

        verticalSpacer = new QSpacerItem(20, 169, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        RecentLineEdit = new QLineEdit(InputPage);
        RecentLineEdit->setObjectName(QString::fromUtf8("RecentLineEdit"));

        horizontalLayout_5->addWidget(RecentLineEdit);

        RecentButton = new QPushButton(InputPage);
        RecentButton->setObjectName(QString::fromUtf8("RecentButton"));

        horizontalLayout_5->addWidget(RecentButton);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        InputButton = new QPushButton(InputPage);
        InputButton->setObjectName(QString::fromUtf8("InputButton"));

        horizontalLayout->addWidget(InputButton);

        CancelButton = new QPushButton(InputPage);
        CancelButton->setObjectName(QString::fromUtf8("CancelButton"));

        horizontalLayout->addWidget(CancelButton);

        ModifyButton = new QPushButton(InputPage);
        ModifyButton->setObjectName(QString::fromUtf8("ModifyButton"));

        horizontalLayout->addWidget(ModifyButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        toolBox->addItem(InputPage, QString::fromUtf8("Input"));
        SearchPage = new QWidget();
        SearchPage->setObjectName(QString::fromUtf8("SearchPage"));
        SearchPage->setGeometry(QRect(0, 0, 326, 316));
        verticalLayout_2 = new QVBoxLayout(SearchPage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        TBSearchView = new QTableView(SearchPage);
        TBSearchView->setObjectName(QString::fromUtf8("TBSearchView"));

        verticalLayout_2->addWidget(TBSearchView);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        SearchComboBox = new QComboBox(SearchPage);
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->addItem(QString());
        SearchComboBox->setObjectName(QString::fromUtf8("SearchComboBox"));

        horizontalLayout_4->addWidget(SearchComboBox);

        SearchLineEdit = new QLineEdit(SearchPage);
        SearchLineEdit->setObjectName(QString::fromUtf8("SearchLineEdit"));

        horizontalLayout_4->addWidget(SearchLineEdit);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        Search = new QPushButton(SearchPage);
        Search->setObjectName(QString::fromUtf8("Search"));

        horizontalLayout_3->addWidget(Search);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);


        verticalLayout_2->addLayout(horizontalLayout_3);

        toolBox->addItem(SearchPage, QString::fromUtf8("Search"));
        splitter->addWidget(toolBox);

        horizontalLayout_2->addWidget(splitter);


        retranslateUi(ProductManager);

        toolBox->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(ProductManager);
    } // setupUi

    void retranslateUi(QWidget *ProductManager)
    {
        ProductManager->setWindowTitle(QCoreApplication::translate("ProductManager", "Form", nullptr));
        label->setText(QCoreApplication::translate("ProductManager", "ProductID", nullptr));
        label_2->setText(QCoreApplication::translate("ProductManager", "ProductName", nullptr));
        label_3->setText(QCoreApplication::translate("ProductManager", "ProductCompany", nullptr));
        label_4->setText(QCoreApplication::translate("ProductManager", "ProductPrice", nullptr));
        RecentButton->setText(QCoreApplication::translate("ProductManager", "Recent", nullptr));
        InputButton->setText(QCoreApplication::translate("ProductManager", "Input", nullptr));
        CancelButton->setText(QCoreApplication::translate("ProductManager", "Cancel", nullptr));
        ModifyButton->setText(QCoreApplication::translate("ProductManager", "Modify", nullptr));
        toolBox->setItemText(toolBox->indexOf(InputPage), QCoreApplication::translate("ProductManager", "Input", nullptr));
        SearchComboBox->setItemText(0, QCoreApplication::translate("ProductManager", "ProductID", nullptr));
        SearchComboBox->setItemText(1, QCoreApplication::translate("ProductManager", "ProductName", nullptr));
        SearchComboBox->setItemText(2, QCoreApplication::translate("ProductManager", "ProductCompany", nullptr));
        SearchComboBox->setItemText(3, QCoreApplication::translate("ProductManager", "ProductPrice", nullptr));

        Search->setText(QCoreApplication::translate("ProductManager", "Search", nullptr));
        toolBox->setItemText(toolBox->indexOf(SearchPage), QCoreApplication::translate("ProductManager", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProductManager: public Ui_ProductManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTMANAGER_H
