/********************************************************************************
** Form generated from reading UI file 'shoppingmanager.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGMANAGER_H
#define UI_SHOPPINGMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingManager
{
public:
    QHBoxLayout *horizontalLayout_5;
    QSplitter *splitter;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *InputPage;
    QVBoxLayout *verticalLayout_2;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *SIDLineEdit;
    QLabel *label_2;
    QLineEdit *ClientLineEdit;
    QLabel *label_3;
    QLineEdit *ProductLineEdit;
    QLabel *label_5;
    QDateEdit *SDateLineEdit;
    QLabel *label_6;
    QLineEdit *SQuanLineEdit;
    QLabel *label_4;
    QLineEdit *SAllPriceLineEdit;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *RecentLineEdit;
    QPushButton *RecentButton;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *InputButton;
    QPushButton *CancelButton;
    QPushButton *ModifyButton;
    QSpacerItem *horizontalSpacer_4;
    QWidget *SearchPage;
    QVBoxLayout *verticalLayout;
    QTableView *TBSearchView;
    QHBoxLayout *horizontalLayout_2;
    QComboBox *comboBox;
    QLineEdit *SearchLineEdit;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *SearchButton;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *ShoppingManager)
    {
        if (ShoppingManager->objectName().isEmpty())
            ShoppingManager->setObjectName(QString::fromUtf8("ShoppingManager"));
        ShoppingManager->resize(660, 437);
        horizontalLayout_5 = new QHBoxLayout(ShoppingManager);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        splitter = new QSplitter(ShoppingManager);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        tableView = new QTableView(splitter);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        splitter->addWidget(tableView);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        InputPage = new QWidget();
        InputPage->setObjectName(QString::fromUtf8("InputPage"));
        InputPage->setGeometry(QRect(0, 0, 373, 377));
        verticalLayout_2 = new QVBoxLayout(InputPage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(InputPage);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        SIDLineEdit = new QLineEdit(InputPage);
        SIDLineEdit->setObjectName(QString::fromUtf8("SIDLineEdit"));
        SIDLineEdit->setReadOnly(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, SIDLineEdit);

        label_2 = new QLabel(InputPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        ClientLineEdit = new QLineEdit(InputPage);
        ClientLineEdit->setObjectName(QString::fromUtf8("ClientLineEdit"));
        ClientLineEdit->setReadOnly(true);

        formLayout->setWidget(1, QFormLayout::FieldRole, ClientLineEdit);

        label_3 = new QLabel(InputPage);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        ProductLineEdit = new QLineEdit(InputPage);
        ProductLineEdit->setObjectName(QString::fromUtf8("ProductLineEdit"));
        ProductLineEdit->setReadOnly(true);

        formLayout->setWidget(2, QFormLayout::FieldRole, ProductLineEdit);

        label_5 = new QLabel(InputPage);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_5);

        SDateLineEdit = new QDateEdit(InputPage);
        SDateLineEdit->setObjectName(QString::fromUtf8("SDateLineEdit"));
        SDateLineEdit->setCalendarPopup(true);

        formLayout->setWidget(3, QFormLayout::FieldRole, SDateLineEdit);

        label_6 = new QLabel(InputPage);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_6);

        SQuanLineEdit = new QLineEdit(InputPage);
        SQuanLineEdit->setObjectName(QString::fromUtf8("SQuanLineEdit"));

        formLayout->setWidget(4, QFormLayout::FieldRole, SQuanLineEdit);

        label_4 = new QLabel(InputPage);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout->setWidget(5, QFormLayout::LabelRole, label_4);

        SAllPriceLineEdit = new QLineEdit(InputPage);
        SAllPriceLineEdit->setObjectName(QString::fromUtf8("SAllPriceLineEdit"));
        SAllPriceLineEdit->setReadOnly(true);

        formLayout->setWidget(5, QFormLayout::FieldRole, SAllPriceLineEdit);


        verticalLayout_2->addLayout(formLayout);

        verticalSpacer = new QSpacerItem(20, 178, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        RecentLineEdit = new QLineEdit(InputPage);
        RecentLineEdit->setObjectName(QString::fromUtf8("RecentLineEdit"));

        horizontalLayout_4->addWidget(RecentLineEdit);

        RecentButton = new QPushButton(InputPage);
        RecentButton->setObjectName(QString::fromUtf8("RecentButton"));

        horizontalLayout_4->addWidget(RecentButton);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        InputButton = new QPushButton(InputPage);
        InputButton->setObjectName(QString::fromUtf8("InputButton"));

        horizontalLayout_3->addWidget(InputButton);

        CancelButton = new QPushButton(InputPage);
        CancelButton->setObjectName(QString::fromUtf8("CancelButton"));

        horizontalLayout_3->addWidget(CancelButton);

        ModifyButton = new QPushButton(InputPage);
        ModifyButton->setObjectName(QString::fromUtf8("ModifyButton"));

        horizontalLayout_3->addWidget(ModifyButton);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);


        verticalLayout_2->addLayout(horizontalLayout_3);

        toolBox->addItem(InputPage, QString::fromUtf8("Input"));
        SearchPage = new QWidget();
        SearchPage->setObjectName(QString::fromUtf8("SearchPage"));
        SearchPage->setGeometry(QRect(0, 0, 373, 377));
        verticalLayout = new QVBoxLayout(SearchPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        TBSearchView = new QTableView(SearchPage);
        TBSearchView->setObjectName(QString::fromUtf8("TBSearchView"));

        verticalLayout->addWidget(TBSearchView);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        comboBox = new QComboBox(SearchPage);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        horizontalLayout_2->addWidget(comboBox);

        SearchLineEdit = new QLineEdit(SearchPage);
        SearchLineEdit->setObjectName(QString::fromUtf8("SearchLineEdit"));

        horizontalLayout_2->addWidget(SearchLineEdit);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        SearchButton = new QPushButton(SearchPage);
        SearchButton->setObjectName(QString::fromUtf8("SearchButton"));

        horizontalLayout->addWidget(SearchButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        toolBox->addItem(SearchPage, QString::fromUtf8("Search"));
        splitter->addWidget(toolBox);

        horizontalLayout_5->addWidget(splitter);


        retranslateUi(ShoppingManager);

        toolBox->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(ShoppingManager);
    } // setupUi

    void retranslateUi(QWidget *ShoppingManager)
    {
        ShoppingManager->setWindowTitle(QCoreApplication::translate("ShoppingManager", "Form", nullptr));
        label->setText(QCoreApplication::translate("ShoppingManager", "ShippingID", nullptr));
        label_2->setText(QCoreApplication::translate("ShoppingManager", "ClientName", nullptr));
        label_3->setText(QCoreApplication::translate("ShoppingManager", "ProductName", nullptr));
        label_5->setText(QCoreApplication::translate("ShoppingManager", "Date", nullptr));
        label_6->setText(QCoreApplication::translate("ShoppingManager", "quan", nullptr));
        label_4->setText(QCoreApplication::translate("ShoppingManager", "ProductPrice", nullptr));
        RecentButton->setText(QCoreApplication::translate("ShoppingManager", "Recent", nullptr));
        InputButton->setText(QCoreApplication::translate("ShoppingManager", "Input", nullptr));
        CancelButton->setText(QCoreApplication::translate("ShoppingManager", "Cancel", nullptr));
        ModifyButton->setText(QCoreApplication::translate("ShoppingManager", "Modify", nullptr));
        toolBox->setItemText(toolBox->indexOf(InputPage), QCoreApplication::translate("ShoppingManager", "Input", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("ShoppingManager", "ShoppingID", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("ShoppingManager", "ClientName", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("ShoppingManager", "ProductName", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("ShoppingManager", "Date", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("ShoppingManager", "quan", nullptr));

        SearchButton->setText(QCoreApplication::translate("ShoppingManager", "Search", nullptr));
        toolBox->setItemText(toolBox->indexOf(SearchPage), QCoreApplication::translate("ShoppingManager", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoppingManager: public Ui_ShoppingManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGMANAGER_H
