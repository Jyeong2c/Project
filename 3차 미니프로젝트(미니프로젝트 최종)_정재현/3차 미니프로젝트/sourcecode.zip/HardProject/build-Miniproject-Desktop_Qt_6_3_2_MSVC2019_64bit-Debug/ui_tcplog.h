/********************************************************************************
** Form generated from reading UI file 'tcplog.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TCPLOG_H
#define UI_TCPLOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_tcplog
{
public:
    QHBoxLayout *horizontalLayout_2;
    QSplitter *splitter;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QTreeWidget *treeWidget;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QTreeWidget *logtreeWidget;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *clearButton;
    QPushButton *saveButton;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *tcplog)
    {
        if (tcplog->objectName().isEmpty())
            tcplog->setObjectName(QString::fromUtf8("tcplog"));
        tcplog->resize(602, 270);
        horizontalLayout_2 = new QHBoxLayout(tcplog);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        splitter = new QSplitter(tcplog);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        widget = new QWidget(splitter);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        treeWidget = new QTreeWidget(widget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("Icon"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setProperty("showDropIndicator", QVariant(true));
        treeWidget->setHeaderHidden(true);

        verticalLayout_2->addWidget(treeWidget);

        splitter->addWidget(widget);
        widget1 = new QWidget(splitter);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        logtreeWidget = new QTreeWidget(widget1);
        logtreeWidget->setObjectName(QString::fromUtf8("logtreeWidget"));

        verticalLayout->addWidget(logtreeWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        clearButton = new QPushButton(widget1);
        clearButton->setObjectName(QString::fromUtf8("clearButton"));

        horizontalLayout->addWidget(clearButton);

        saveButton = new QPushButton(widget1);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));

        horizontalLayout->addWidget(saveButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        splitter->addWidget(widget1);

        horizontalLayout_2->addWidget(splitter);


        retranslateUi(tcplog);
        QObject::connect(clearButton, &QPushButton::clicked, logtreeWidget, qOverload<>(&QTreeWidget::clear));

        QMetaObject::connectSlotsByName(tcplog);
    } // setupUi

    void retranslateUi(QWidget *tcplog)
    {
        tcplog->setWindowTitle(QCoreApplication::translate("tcplog", "Form", nullptr));
        label->setText(QCoreApplication::translate("tcplog", "Client List", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget->headerItem();
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("tcplog", "text", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("tcplog", "Name", nullptr));
        QTreeWidgetItem *___qtreewidgetitem1 = logtreeWidget->headerItem();
        ___qtreewidgetitem1->setText(5, QCoreApplication::translate("tcplog", "Time", nullptr));
        ___qtreewidgetitem1->setText(4, QCoreApplication::translate("tcplog", "Message", nullptr));
        ___qtreewidgetitem1->setText(3, QCoreApplication::translate("tcplog", "Name", nullptr));
        ___qtreewidgetitem1->setText(2, QCoreApplication::translate("tcplog", "ID", nullptr));
        ___qtreewidgetitem1->setText(1, QCoreApplication::translate("tcplog", "Port", nullptr));
        ___qtreewidgetitem1->setText(0, QCoreApplication::translate("tcplog", "IP", nullptr));
        clearButton->setText(QCoreApplication::translate("tcplog", "ClearButton", nullptr));
        saveButton->setText(QCoreApplication::translate("tcplog", "SaveButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class tcplog: public Ui_tcplog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TCPLOG_H
