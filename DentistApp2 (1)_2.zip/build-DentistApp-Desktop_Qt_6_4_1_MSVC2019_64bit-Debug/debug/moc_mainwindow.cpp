/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DentistApp/mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[48];
    char stringdata0[11];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[13];
    char stringdata5[15];
    char stringdata6[11];
    char stringdata7[17];
    char stringdata8[15];
    char stringdata9[32];
    char stringdata10[18];
    char stringdata11[15];
    char stringdata12[5];
    char stringdata13[13];
    char stringdata14[34];
    char stringdata15[36];
    char stringdata16[29];
    char stringdata17[31];
    char stringdata18[34];
    char stringdata19[36];
    char stringdata20[33];
    char stringdata21[10];
    char stringdata22[31];
    char stringdata23[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 16),  // "brightDownSlider"
        QT_MOC_LITERAL(28, 0),  // ""
        QT_MOC_LITERAL(29, 14),  // "brightUpSlider"
        QT_MOC_LITERAL(44, 12),  // "brightSlider"
        QT_MOC_LITERAL(57, 14),  // "contrastSignal"
        QT_MOC_LITERAL(72, 10),  // "selectItem"
        QT_MOC_LITERAL(83, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(100, 14),  // "previousScreen"
        QT_MOC_LITERAL(115, 31),  // "on_imageClearPushButton_clicked"
        QT_MOC_LITERAL(147, 17),  // "layoutSizeChanged"
        QT_MOC_LITERAL(165, 14),  // "QGraphicsView*"
        QT_MOC_LITERAL(180, 4),  // "grid"
        QT_MOC_LITERAL(185, 12),  // "DoubleWidget"
        QT_MOC_LITERAL(198, 33),  // "on_brightnessUpToolButton_cli..."
        QT_MOC_LITERAL(232, 35),  // "on_brightnessDownToolButton_c..."
        QT_MOC_LITERAL(268, 28),  // "on_sharpenToolButton_clicked"
        QT_MOC_LITERAL(297, 30),  // "on_inversionToolButton_clicked"
        QT_MOC_LITERAL(328, 33),  // "on_verticalFlipToolButton_cli..."
        QT_MOC_LITERAL(362, 35),  // "on_horizontalFlipToolButton_c..."
        QT_MOC_LITERAL(398, 32),  // "on_brightnessSlider_valueChanged"
        QT_MOC_LITERAL(431, 9),  // "intensity"
        QT_MOC_LITERAL(441, 30),  // "on_contrastSlider_valueChanged"
        QT_MOC_LITERAL(472, 5)   // "alpha"
    },
    "MainWindow",
    "brightDownSlider",
    "",
    "brightUpSlider",
    "brightSlider",
    "contrastSignal",
    "selectItem",
    "QListWidgetItem*",
    "previousScreen",
    "on_imageClearPushButton_clicked",
    "layoutSizeChanged",
    "QGraphicsView*",
    "grid",
    "DoubleWidget",
    "on_brightnessUpToolButton_clicked",
    "on_brightnessDownToolButton_clicked",
    "on_sharpenToolButton_clicked",
    "on_inversionToolButton_clicked",
    "on_verticalFlipToolButton_clicked",
    "on_horizontalFlipToolButton_clicked",
    "on_brightnessSlider_valueChanged",
    "intensity",
    "on_contrastSlider_valueChanged",
    "alpha"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  116,    2, 0x06,    1 /* Public */,
       3,    1,  119,    2, 0x06,    3 /* Public */,
       4,    1,  122,    2, 0x06,    5 /* Public */,
       5,    1,  125,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    1,  128,    2, 0x0a,    9 /* Public */,
       8,    0,  131,    2, 0x0a,   11 /* Public */,
       9,    0,  132,    2, 0x08,   12 /* Private */,
      10,    1,  133,    2, 0x08,   13 /* Private */,
      13,    1,  136,    2, 0x08,   15 /* Private */,
      14,    0,  139,    2, 0x08,   17 /* Private */,
      15,    0,  140,    2, 0x08,   18 /* Private */,
      16,    0,  141,    2, 0x08,   19 /* Private */,
      17,    0,  142,    2, 0x08,   20 /* Private */,
      18,    0,  143,    2, 0x08,   21 /* Private */,
      19,    0,  144,    2, 0x08,   22 /* Private */,
      20,    1,  145,    2, 0x08,   23 /* Private */,
      22,    1,  148,    2, 0x08,   25 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   23,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'brightDownSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'brightUpSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'brightSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'contrastSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'selectItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'previousScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_imageClearPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'layoutSizeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'DoubleWidget'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'on_brightnessUpToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_brightnessDownToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sharpenToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_inversionToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_verticalFlipToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_horizontalFlipToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_brightnessSlider_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_contrastSlider_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->brightDownSlider((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->brightUpSlider((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->brightSlider((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->contrastSignal((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->selectItem((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 5: _t->previousScreen(); break;
        case 6: _t->on_imageClearPushButton_clicked(); break;
        case 7: _t->layoutSizeChanged((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 8: _t->DoubleWidget((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 9: _t->on_brightnessUpToolButton_clicked(); break;
        case 10: _t->on_brightnessDownToolButton_clicked(); break;
        case 11: _t->on_sharpenToolButton_clicked(); break;
        case 12: _t->on_inversionToolButton_clicked(); break;
        case 13: _t->on_verticalFlipToolButton_clicked(); break;
        case 14: _t->on_horizontalFlipToolButton_clicked(); break;
        case 15: _t->on_brightnessSlider_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 16: _t->on_contrastSlider_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(int );
            if (_t _q_method = &MainWindow::brightDownSlider; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (_t _q_method = &MainWindow::brightUpSlider; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (_t _q_method = &MainWindow::brightSlider; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (_t _q_method = &MainWindow::contrastSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::brightDownSlider(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::brightUpSlider(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::brightSlider(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::contrastSignal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
