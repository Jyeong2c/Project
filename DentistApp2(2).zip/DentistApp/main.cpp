//#include "mainwindow.h"
#include <QApplication>
#include "loginpage.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    LoginPage w;
    MainWindow  w;
    w.show();
    return a.exec();

//    QApplication a(argc, argv);
//    Layout L;
//    L.show();
//    return a.exec();

//    QApplication a(argc, argv);
//    FMX X;
//    X.show();
//    return a.exec();
}
