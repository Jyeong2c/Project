#ifndef LAYOUT_H
#define LAYOUT_H

#include "scene.h"
#include <QWidget>
#include <QList>

class QGraphicsScene;
class QGraphicsView;

class Layout : public QWidget
{
    Q_OBJECT
public:
    explicit Layout(QWidget *parent = nullptr);
    QGraphicsView *grid1;

public slots:
    void brightUp();
    void brightnessLow();
    void inverstion();
    void verticalFlip();
    void horizontalFlip();
    void sharpen();
    void zoomIn();
    void zoomOut();
    void leftRotate();
    void rightRotate();

    void brightnessUpOpenCV();
    void brightnessDownOpenCV();
    void brightSlider(int);
    void his();
    void imageClear();
    void contrast();
    void contrast2(int);


private:
    void gridLayout();
    QImage * m_image;
    QImage * m_copyImage;

    QGraphicsView *grid2;
    QGraphicsScene* scene;
//    Scene * ;
//    QImage *image_to_display;



    int intensity=0;
    int inten=0;
    int cnt=0;
    float alpha = 0.0f;

signals:


};

#endif // LAYOUT_H
