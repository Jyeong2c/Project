#ifndef LOGINPAGE_H
#define LOGINPAGE_H

#include <QMainWindow>
#include "mainwindow.h"

class QSqlQuery;
class QSqlTableModel;


namespace Ui {
class LoginPage;
}

class LoginPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit LoginPage(QWidget *parent = nullptr);
    ~LoginPage();
//    QString userName;
signals:
//    void selectUserName();
    void selectUserName(QString);

private slots:
    void on_loginPushButton_clicked();

private:
    Ui::LoginPage *ui;
    MainWindow * mainWindow;

    void patientLoad();

    QSqlQuery *patientQuery;
    QSqlTableModel *patientQueryModel;

};

#endif // LOGINPAGE_H
