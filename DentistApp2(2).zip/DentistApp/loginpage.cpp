#include "loginpage.h"
#include "ui_loginpage.h"
#include <QMessageBox>



#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlQueryModel>
#include <QTableView>
#include <QGraphicsView>
#include <QList>
#include <QStandardItem>


LoginPage::LoginPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginPage)
{
    ui->setupUi(this);

//     patientLoad();
//    ui->graphicsView->sets
    mainWindow = new MainWindow(this);
//    connect(this,SIGNAL(selectUserName()),mainWindow,SLOT(userNameOne()));
    connect(this,SIGNAL(selectUserName(QString)),mainWindow,SLOT(userNameOne(QString)));
//    connect(ui->loginPushButton,SIGNAL(clicked()),mainWindow,SLOT(userNameOne()));
}

LoginPage::~LoginPage()
{
    delete ui;
//    QSqlDatabase clDB = QSqlDatabase::database("patientDB");  //데이터베이스 닫기
//    if(clDB.isOpen()){                                               //만약 파일이 열리면
//        patientQueryModel->submitAll();
//        delete patientQueryModel;
//        clDB.close();
//        QSqlDatabase::removeDatabase("patientDB");
//    }
}

void LoginPage::on_loginPushButton_clicked()
{
    QString userName = ui->userLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    if(userName == "osstem1" && password == "1234"){
        QMessageBox::information(this,"Login","correct");
        hide();
        mainWindow = new MainWindow(this);
        emit selectUserName(userName);
        mainWindow->show();
    }else if(userName == "osstem2" && password == "5678"){
        QMessageBox::information(this,"Login","correct");
        hide();
        mainWindow = new MainWindow(this);
        emit selectUserName(userName);
        mainWindow->show();
    }else{
        QMessageBox::information(this,"Login","This is not valid. Please try again.");
    }
}

//void LoginPage::patientLoad()
//{
//    //QSQLITE 파일로 데이터 베이스 생성                  //데이터베이스가 2개 이상 사용으로 이름 설정
//    QSqlDatabase DB = QSqlDatabase::addDatabase("QSQLITE");
//    DB.setDatabaseName("patientDB.db");                             //데이터베이스 이름설정

//    if(DB.open()){                                                 //조건문
//        patientQuery = new QSqlQuery(DB);
//        //query 문을 이용하여 테이블 생성 및 PK 키 설정
//        //        patientQuery->exec("DELETE ")

//        patientQuery->exec("CREATE TABLE IF NOT EXISTS patient(chartNum INTEGER Primary Key,"
//                           "name VARCHAR(20) NOT NULL, age INTEGER,imagePath VARCHAR(20));");

//        patientQueryModel = new QSqlTableModel(this, DB);
//        patientQueryModel->setTable("patient");
//        patientQueryModel->select();

//        /*테이블 헤더 설정*/
//        patientQueryModel->setHeaderData(0, Qt::Horizontal, QObject::tr("ChartNum"));
//        patientQueryModel->setHeaderData(1, Qt::Horizontal, QObject::tr("Name"));
//        patientQueryModel->setHeaderData(2, Qt::Horizontal, QObject::tr("Age"));
//        patientQueryModel->setHeaderData(3, Qt::Horizontal, QObject::tr("ImagePath"));

//        ui->patientTableView->setModel(patientQueryModel);

//        ui->patientTableView->hideColumn(3);

//        patientQuery->exec("INSERT INTO patient VALUES (1000,'JaeYeong','28','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1001,'Yuna','26','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1002,'Jaehyun','27','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1003,'eunji','29','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1004,'chelly','28','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1005,'brian','26','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1006,'dessery','27','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1007,'1','29','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1008,'2','26','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1009,'3','27','..')");
//        patientQuery->exec("INSERT INTO patient VALUES (1010,'4','29','..')");
//        patientQueryModel->select();
//        ui->patientTableView->resizeColumnsToContents();

//    }
//}
