/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMdiArea>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSave;
    QAction *actionRedo;
    QAction *actionUndo;
    QWidget *centralwidget;
    QSplitter *splitter3;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *userNameLineEdit;
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout;
    QGroupBox *brushGroupBox;
    QHBoxLayout *horizontalLayout_6;
    QToolButton *brushToolButton;
    QSpinBox *spinBox;
    QGroupBox *figureGroupBox;
    QHBoxLayout *horizontalLayout_3;
    QToolButton *circleToolButton;
    QToolButton *triangleToolButton;
    QToolButton *rectangleToolButton;
    QToolButton *arrowToolButton;
    QGroupBox *colorGroupBox;
    QHBoxLayout *horizontalLayout_4;
    QToolButton *colorToolButton;
    QWidget *tab_4;
    QGridLayout *gridLayout_2;
    QGroupBox *imageGroupBox;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_7;
    QToolButton *brightToolButton;
    QToolButton *brightnessToolButton;
    QToolButton *sharpenToolButton;
    QSlider *horizontalSlider;
    QHBoxLayout *horizontalLayout_9;
    QToolButton *inversionToolButton;
    QToolButton *verticalFlipToolButton;
    QToolButton *horizontalFlipToolButton;
    QHBoxLayout *horizontalLayout_10;
    QToolButton *zoomInToolButton;
    QToolButton *zoomOutToolButton;
    QToolButton *panningToolButton;
    QHBoxLayout *horizontalLayout_12;
    QToolButton *leftRotateToolButton;
    QToolButton *contrastToolButton;
    QToolButton *rightRotateToolButton;
    QSlider *contrastHorizontalSlider;
    QWidget *tab;
    QVBoxLayout *verticalLayout_6;
    QGroupBox *measureGroupBox;
    QHBoxLayout *horizontalLayout_5;
    QToolButton *rulerToolButton;
    QToolButton *measureToolButton;
    QToolButton *protractorToolButton;
    QGroupBox *implantGroupBox;
    QHBoxLayout *horizontalLayout_11;
    QToolButton *implantToolButton;
    QToolButton *implantToolButton_2;
    QGroupBox *groupBox_6;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *drawPushButton;
    QPushButton *imagePushButton;
    QTableView *patientTableView;
    QSplitter *splitter2;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_14;
    QSplitter *splitter;
    QMdiArea *mdiArea;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_2;
    QTreeWidget *treeWidget;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QToolButton *toolButton;
    QSpacerItem *horizontalSpacer;
    QToolButton *toolButton_2;
    QSpacerItem *horizontalSpacer_2;
    QTreeWidget *treeWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_4;
    QToolButton *toolButton_3;
    QSpacerItem *horizontalSpacer_5;
    QToolButton *toolButton_4;
    QSpacerItem *horizontalSpacer_6;
    QFrame *line;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_15;
    QSpacerItem *verticalSpacer;
    QListWidget *listWidget;
    QMenuBar *menubar;
    QMenu *menuMenu;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1248, 681);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName("actionSave");
        actionRedo = new QAction(MainWindow);
        actionRedo->setObjectName("actionRedo");
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName("actionUndo");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        splitter3 = new QSplitter(centralwidget);
        splitter3->setObjectName("splitter3");
        splitter3->setGeometry(QRect(7, 6, 1374, 752));
        splitter3->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter3);
        layoutWidget->setObjectName("layoutWidget");
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        userNameLineEdit = new QLineEdit(layoutWidget);
        userNameLineEdit->setObjectName("userNameLineEdit");
        userNameLineEdit->setReadOnly(true);

        verticalLayout_4->addWidget(userNameLineEdit);

        tabWidget = new QTabWidget(layoutWidget);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setTabPosition(QTabWidget::West);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tab_3 = new QWidget();
        tab_3->setObjectName("tab_3");
        verticalLayout = new QVBoxLayout(tab_3);
        verticalLayout->setObjectName("verticalLayout");
        brushGroupBox = new QGroupBox(tab_3);
        brushGroupBox->setObjectName("brushGroupBox");
        horizontalLayout_6 = new QHBoxLayout(brushGroupBox);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        brushToolButton = new QToolButton(brushGroupBox);
        brushToolButton->setObjectName("brushToolButton");
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/draw2.png"), QSize(), QIcon::Normal, QIcon::Off);
        brushToolButton->setIcon(icon);

        horizontalLayout_6->addWidget(brushToolButton);

        spinBox = new QSpinBox(brushGroupBox);
        spinBox->setObjectName("spinBox");

        horizontalLayout_6->addWidget(spinBox);


        verticalLayout->addWidget(brushGroupBox);

        figureGroupBox = new QGroupBox(tab_3);
        figureGroupBox->setObjectName("figureGroupBox");
        horizontalLayout_3 = new QHBoxLayout(figureGroupBox);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        circleToolButton = new QToolButton(figureGroupBox);
        circleToolButton->setObjectName("circleToolButton");
        circleToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/circle2.png"), QSize(), QIcon::Normal, QIcon::Off);
        circleToolButton->setIcon(icon1);
        circleToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_3->addWidget(circleToolButton);

        triangleToolButton = new QToolButton(figureGroupBox);
        triangleToolButton->setObjectName("triangleToolButton");
        triangleToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Image/triangle2.png"), QSize(), QIcon::Normal, QIcon::Off);
        triangleToolButton->setIcon(icon2);
        triangleToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_3->addWidget(triangleToolButton);

        rectangleToolButton = new QToolButton(figureGroupBox);
        rectangleToolButton->setObjectName("rectangleToolButton");
        rectangleToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Image/rectangle2.png"), QSize(), QIcon::Normal, QIcon::Off);
        rectangleToolButton->setIcon(icon3);
        rectangleToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_3->addWidget(rectangleToolButton);

        arrowToolButton = new QToolButton(figureGroupBox);
        arrowToolButton->setObjectName("arrowToolButton");
        arrowToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Image/arrow3.png"), QSize(), QIcon::Normal, QIcon::Off);
        arrowToolButton->setIcon(icon4);
        arrowToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_3->addWidget(arrowToolButton);


        verticalLayout->addWidget(figureGroupBox);

        colorGroupBox = new QGroupBox(tab_3);
        colorGroupBox->setObjectName("colorGroupBox");
        horizontalLayout_4 = new QHBoxLayout(colorGroupBox);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        colorToolButton = new QToolButton(colorGroupBox);
        colorToolButton->setObjectName("colorToolButton");
        colorToolButton->setLayoutDirection(Qt::LeftToRight);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/Image/color.png"), QSize(), QIcon::Normal, QIcon::Off);
        colorToolButton->setIcon(icon5);
        colorToolButton->setIconSize(QSize(150, 15));

        horizontalLayout_4->addWidget(colorToolButton);


        verticalLayout->addWidget(colorGroupBox);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName("tab_4");
        gridLayout_2 = new QGridLayout(tab_4);
        gridLayout_2->setObjectName("gridLayout_2");
        imageGroupBox = new QGroupBox(tab_4);
        imageGroupBox->setObjectName("imageGroupBox");
        verticalLayout_3 = new QVBoxLayout(imageGroupBox);
        verticalLayout_3->setObjectName("verticalLayout_3");
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        brightToolButton = new QToolButton(imageGroupBox);
        brightToolButton->setObjectName("brightToolButton");
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/Image/bright.png"), QSize(), QIcon::Normal, QIcon::Off);
        brightToolButton->setIcon(icon6);
        brightToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(brightToolButton);

        brightnessToolButton = new QToolButton(imageGroupBox);
        brightnessToolButton->setObjectName("brightnessToolButton");
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/Image/brightness.png"), QSize(), QIcon::Normal, QIcon::Off);
        brightnessToolButton->setIcon(icon7);
        brightnessToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(brightnessToolButton);

        sharpenToolButton = new QToolButton(imageGroupBox);
        sharpenToolButton->setObjectName("sharpenToolButton");
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/Image/sharpen.png"), QSize(), QIcon::Normal, QIcon::Off);
        sharpenToolButton->setIcon(icon8);
        sharpenToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_7->addWidget(sharpenToolButton);


        verticalLayout_3->addLayout(horizontalLayout_7);

        horizontalSlider = new QSlider(imageGroupBox);
        horizontalSlider->setObjectName("horizontalSlider");
        horizontalSlider->setMaximum(100);
        horizontalSlider->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(horizontalSlider);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        inversionToolButton = new QToolButton(imageGroupBox);
        inversionToolButton->setObjectName("inversionToolButton");
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/Image/Contrast.png"), QSize(), QIcon::Normal, QIcon::Off);
        inversionToolButton->setIcon(icon9);
        inversionToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_9->addWidget(inversionToolButton);

        verticalFlipToolButton = new QToolButton(imageGroupBox);
        verticalFlipToolButton->setObjectName("verticalFlipToolButton");
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/Image/vertical flip.png"), QSize(), QIcon::Normal, QIcon::Off);
        verticalFlipToolButton->setIcon(icon10);
        verticalFlipToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_9->addWidget(verticalFlipToolButton);

        horizontalFlipToolButton = new QToolButton(imageGroupBox);
        horizontalFlipToolButton->setObjectName("horizontalFlipToolButton");
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/Image/horizontal flip.png"), QSize(), QIcon::Normal, QIcon::Off);
        horizontalFlipToolButton->setIcon(icon11);
        horizontalFlipToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_9->addWidget(horizontalFlipToolButton);


        verticalLayout_3->addLayout(horizontalLayout_9);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName("horizontalLayout_10");
        zoomInToolButton = new QToolButton(imageGroupBox);
        zoomInToolButton->setObjectName("zoomInToolButton");
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/Image/zoom.png"), QSize(), QIcon::Normal, QIcon::Off);
        zoomInToolButton->setIcon(icon12);
        zoomInToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_10->addWidget(zoomInToolButton);

        zoomOutToolButton = new QToolButton(imageGroupBox);
        zoomOutToolButton->setObjectName("zoomOutToolButton");
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/Image/zoomOut.png"), QSize(), QIcon::Normal, QIcon::Off);
        zoomOutToolButton->setIcon(icon13);
        zoomOutToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_10->addWidget(zoomOutToolButton);

        panningToolButton = new QToolButton(imageGroupBox);
        panningToolButton->setObjectName("panningToolButton");
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/Image/panning.png"), QSize(), QIcon::Normal, QIcon::Off);
        panningToolButton->setIcon(icon14);
        panningToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_10->addWidget(panningToolButton);


        verticalLayout_3->addLayout(horizontalLayout_10);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName("horizontalLayout_12");
        leftRotateToolButton = new QToolButton(imageGroupBox);
        leftRotateToolButton->setObjectName("leftRotateToolButton");
        QIcon icon15;
        icon15.addFile(QString::fromUtf8(":/Image/rotate_L.png"), QSize(), QIcon::Normal, QIcon::Off);
        leftRotateToolButton->setIcon(icon15);
        leftRotateToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_12->addWidget(leftRotateToolButton);

        contrastToolButton = new QToolButton(imageGroupBox);
        contrastToolButton->setObjectName("contrastToolButton");

        horizontalLayout_12->addWidget(contrastToolButton);

        rightRotateToolButton = new QToolButton(imageGroupBox);
        rightRotateToolButton->setObjectName("rightRotateToolButton");
        QIcon icon16;
        icon16.addFile(QString::fromUtf8(":/Image/rotate_R.png"), QSize(), QIcon::Normal, QIcon::Off);
        rightRotateToolButton->setIcon(icon16);
        rightRotateToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_12->addWidget(rightRotateToolButton);


        verticalLayout_3->addLayout(horizontalLayout_12);

        contrastHorizontalSlider = new QSlider(imageGroupBox);
        contrastHorizontalSlider->setObjectName("contrastHorizontalSlider");
        contrastHorizontalSlider->setOrientation(Qt::Horizontal);

        verticalLayout_3->addWidget(contrastHorizontalSlider);


        gridLayout_2->addWidget(imageGroupBox, 0, 0, 1, 1);

        tabWidget->addTab(tab_4, QString());
        tab = new QWidget();
        tab->setObjectName("tab");
        verticalLayout_6 = new QVBoxLayout(tab);
        verticalLayout_6->setObjectName("verticalLayout_6");
        measureGroupBox = new QGroupBox(tab);
        measureGroupBox->setObjectName("measureGroupBox");
        horizontalLayout_5 = new QHBoxLayout(measureGroupBox);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        rulerToolButton = new QToolButton(measureGroupBox);
        rulerToolButton->setObjectName("rulerToolButton");
        rulerToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon17;
        icon17.addFile(QString::fromUtf8(":/Image/ruler.png"), QSize(), QIcon::Normal, QIcon::Off);
        rulerToolButton->setIcon(icon17);
        rulerToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(rulerToolButton);

        measureToolButton = new QToolButton(measureGroupBox);
        measureToolButton->setObjectName("measureToolButton");
        measureToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon18;
        icon18.addFile(QString::fromUtf8(":/Image/measure.png"), QSize(), QIcon::Normal, QIcon::Off);
        measureToolButton->setIcon(icon18);
        measureToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(measureToolButton);

        protractorToolButton = new QToolButton(measureGroupBox);
        protractorToolButton->setObjectName("protractorToolButton");
        protractorToolButton->setMinimumSize(QSize(0, 0));
        QIcon icon19;
        icon19.addFile(QString::fromUtf8(":/Image/progtractor.png"), QSize(), QIcon::Normal, QIcon::Off);
        protractorToolButton->setIcon(icon19);
        protractorToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_5->addWidget(protractorToolButton);


        verticalLayout_6->addWidget(measureGroupBox);

        implantGroupBox = new QGroupBox(tab);
        implantGroupBox->setObjectName("implantGroupBox");
        horizontalLayout_11 = new QHBoxLayout(implantGroupBox);
        horizontalLayout_11->setObjectName("horizontalLayout_11");
        implantToolButton = new QToolButton(implantGroupBox);
        implantToolButton->setObjectName("implantToolButton");
        implantToolButton->setMinimumSize(QSize(100, 0));
        implantToolButton->setSizeIncrement(QSize(0, 0));
        QIcon icon20;
        icon20.addFile(QString::fromUtf8(":/Image/implant.png"), QSize(), QIcon::Normal, QIcon::Off);
        implantToolButton->setIcon(icon20);
        implantToolButton->setIconSize(QSize(30, 30));

        horizontalLayout_11->addWidget(implantToolButton);

        implantToolButton_2 = new QToolButton(implantGroupBox);
        implantToolButton_2->setObjectName("implantToolButton_2");
        implantToolButton_2->setMinimumSize(QSize(100, 0));
        implantToolButton_2->setSizeIncrement(QSize(0, 0));
        implantToolButton_2->setIcon(icon20);
        implantToolButton_2->setIconSize(QSize(30, 30));

        horizontalLayout_11->addWidget(implantToolButton_2);


        verticalLayout_6->addWidget(implantGroupBox);

        tabWidget->addTab(tab, QString());

        verticalLayout_4->addWidget(tabWidget);

        groupBox_6 = new QGroupBox(layoutWidget);
        groupBox_6->setObjectName("groupBox_6");
        horizontalLayout_8 = new QHBoxLayout(groupBox_6);
        horizontalLayout_8->setObjectName("horizontalLayout_8");
        drawPushButton = new QPushButton(groupBox_6);
        drawPushButton->setObjectName("drawPushButton");

        horizontalLayout_8->addWidget(drawPushButton);

        imagePushButton = new QPushButton(groupBox_6);
        imagePushButton->setObjectName("imagePushButton");

        horizontalLayout_8->addWidget(imagePushButton);


        verticalLayout_4->addWidget(groupBox_6);

        patientTableView = new QTableView(layoutWidget);
        patientTableView->setObjectName("patientTableView");
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(patientTableView->sizePolicy().hasHeightForWidth());
        patientTableView->setSizePolicy(sizePolicy);
        patientTableView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        patientTableView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        patientTableView->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContentsOnFirstShow);
        patientTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        patientTableView->setAlternatingRowColors(true);
        patientTableView->setSelectionMode(QAbstractItemView::SingleSelection);
        patientTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        patientTableView->verticalHeader()->setDefaultSectionSize(15);

        verticalLayout_4->addWidget(patientTableView);

        splitter3->addWidget(layoutWidget);
        splitter2 = new QSplitter(splitter3);
        splitter2->setObjectName("splitter2");
        splitter2->setOrientation(Qt::Vertical);
        layoutWidget1 = new QWidget(splitter2);
        layoutWidget1->setObjectName("layoutWidget1");
        verticalLayout_14 = new QVBoxLayout(layoutWidget1);
        verticalLayout_14->setObjectName("verticalLayout_14");
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        splitter = new QSplitter(layoutWidget1);
        splitter->setObjectName("splitter");
        splitter->setOrientation(Qt::Horizontal);
        mdiArea = new QMdiArea(splitter);
        mdiArea->setObjectName("mdiArea");
        mdiArea->setViewMode(QMdiArea::TabbedView);
        splitter->addWidget(mdiArea);
        layoutWidget2 = new QWidget(splitter);
        layoutWidget2->setObjectName("layoutWidget2");
        verticalLayout_2 = new QVBoxLayout(layoutWidget2);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        treeWidget = new QTreeWidget(layoutWidget2);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName("treeWidget");

        verticalLayout_2->addWidget(treeWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalSpacer_3 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        toolButton = new QToolButton(layoutWidget2);
        toolButton->setObjectName("toolButton");

        horizontalLayout->addWidget(toolButton);

        horizontalSpacer = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        toolButton_2 = new QToolButton(layoutWidget2);
        toolButton_2->setObjectName("toolButton_2");

        horizontalLayout->addWidget(toolButton_2);

        horizontalSpacer_2 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout);

        treeWidget_2 = new QTreeWidget(layoutWidget2);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem();
        __qtreewidgetitem1->setText(0, QString::fromUtf8("1"));
        treeWidget_2->setHeaderItem(__qtreewidgetitem1);
        treeWidget_2->setObjectName("treeWidget_2");

        verticalLayout_2->addWidget(treeWidget_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalSpacer_4 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        toolButton_3 = new QToolButton(layoutWidget2);
        toolButton_3->setObjectName("toolButton_3");

        horizontalLayout_2->addWidget(toolButton_3);

        horizontalSpacer_5 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        toolButton_4 = new QToolButton(layoutWidget2);
        toolButton_4->setObjectName("toolButton_4");

        horizontalLayout_2->addWidget(toolButton_4);

        horizontalSpacer_6 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_6);


        verticalLayout_2->addLayout(horizontalLayout_2);

        splitter->addWidget(layoutWidget2);

        verticalLayout_14->addWidget(splitter);

        line = new QFrame(layoutWidget1);
        line->setObjectName("line");
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_14->addWidget(line);

        splitter2->addWidget(layoutWidget1);
        layoutWidget3 = new QWidget(splitter2);
        layoutWidget3->setObjectName("layoutWidget3");
        verticalLayout_15 = new QVBoxLayout(layoutWidget3);
        verticalLayout_15->setObjectName("verticalLayout_15");
        verticalLayout_15->setContentsMargins(0, 0, 0, 0);
        verticalSpacer = new QSpacerItem(20, 12, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_15->addItem(verticalSpacer);

        listWidget = new QListWidget(layoutWidget3);
        listWidget->setObjectName("listWidget");

        verticalLayout_15->addWidget(listWidget);

        splitter2->addWidget(layoutWidget3);
        splitter3->addWidget(splitter2);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1248, 17));
        menuMenu = new QMenu(menubar);
        menuMenu->setObjectName("menuMenu");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName("toolBar");
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        menubar->addAction(menuMenu->menuAction());
        toolBar->addAction(actionSave);
        toolBar->addSeparator();
        toolBar->addAction(actionUndo);
        toolBar->addSeparator();
        toolBar->addAction(actionRedo);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionSave->setText(QCoreApplication::translate("MainWindow", "\354\240\200\354\236\245", nullptr));
        actionRedo->setText(QCoreApplication::translate("MainWindow", "Redo", nullptr));
        actionUndo->setText(QCoreApplication::translate("MainWindow", "Undo", nullptr));
        brushGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Brush", nullptr));
        brushToolButton->setText(QCoreApplication::translate("MainWindow", "Brush", nullptr));
        figureGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Figure", nullptr));
        circleToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        triangleToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        rectangleToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        arrowToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        colorGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Color", nullptr));
        colorToolButton->setText(QCoreApplication::translate("MainWindow", "Color", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "Painter", nullptr));
        imageGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Image", nullptr));
#if QT_CONFIG(tooltip)
        brightToolButton->setToolTip(QCoreApplication::translate("MainWindow", "brightToolButton", nullptr));
#endif // QT_CONFIG(tooltip)
        brightToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
#if QT_CONFIG(tooltip)
        brightnessToolButton->setToolTip(QCoreApplication::translate("MainWindow", "brightnessToolButton", nullptr));
#endif // QT_CONFIG(tooltip)
        brightnessToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        sharpenToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        inversionToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        verticalFlipToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        horizontalFlipToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        zoomInToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        zoomOutToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        panningToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        leftRotateToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        contrastToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        rightRotateToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("MainWindow", "Processing", nullptr));
        measureGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Measure", nullptr));
        rulerToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        measureToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        protractorToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        implantGroupBox->setTitle(QCoreApplication::translate("MainWindow", "Implant", nullptr));
        implantToolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        implantToolButton_2->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "Measure", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("MainWindow", "Initialize", nullptr));
        drawPushButton->setText(QCoreApplication::translate("MainWindow", "Draw", nullptr));
        imagePushButton->setText(QCoreApplication::translate("MainWindow", "Image", nullptr));
        toolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        toolButton_2->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        toolButton_3->setText(QCoreApplication::translate("MainWindow", "Layout\n"
"Save", nullptr));
        toolButton_4->setText(QCoreApplication::translate("MainWindow", "Layout\n"
"Clear", nullptr));
        menuMenu->setTitle(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("MainWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
