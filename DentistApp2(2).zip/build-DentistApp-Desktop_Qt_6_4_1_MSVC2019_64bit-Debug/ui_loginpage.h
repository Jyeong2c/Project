/********************************************************************************
** Form generated from reading UI file 'loginpage.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINPAGE_H
#define UI_LOGINPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginPage
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QGraphicsView *graphicsView;
    QGroupBox *signInGroupBox;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *userLineEdit;
    QLabel *label_2;
    QLineEdit *passwordLineEdit;
    QPushButton *loginPushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LoginPage)
    {
        if (LoginPage->objectName().isEmpty())
            LoginPage->setObjectName("LoginPage");
        LoginPage->resize(800, 600);
        centralwidget = new QWidget(LoginPage);
        centralwidget->setObjectName("centralwidget");
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName("gridLayout_2");
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName("graphicsView");

        gridLayout_2->addWidget(graphicsView, 0, 0, 2, 2);

        signInGroupBox = new QGroupBox(centralwidget);
        signInGroupBox->setObjectName("signInGroupBox");
        gridLayout = new QGridLayout(signInGroupBox);
        gridLayout->setObjectName("gridLayout");
        label = new QLabel(signInGroupBox);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 1);

        userLineEdit = new QLineEdit(signInGroupBox);
        userLineEdit->setObjectName("userLineEdit");

        gridLayout->addWidget(userLineEdit, 0, 1, 1, 1);

        label_2 = new QLabel(signInGroupBox);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        passwordLineEdit = new QLineEdit(signInGroupBox);
        passwordLineEdit->setObjectName("passwordLineEdit");
        passwordLineEdit->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(passwordLineEdit, 1, 1, 1, 1);

        loginPushButton = new QPushButton(signInGroupBox);
        loginPushButton->setObjectName("loginPushButton");

        gridLayout->addWidget(loginPushButton, 2, 1, 1, 1);


        gridLayout_2->addWidget(signInGroupBox, 1, 1, 1, 1);

        LoginPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 17));
        LoginPage->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginPage);
        statusbar->setObjectName("statusbar");
        LoginPage->setStatusBar(statusbar);
#if QT_CONFIG(shortcut)
        label->setBuddy(userLineEdit);
        label_2->setBuddy(passwordLineEdit);
#endif // QT_CONFIG(shortcut)

        retranslateUi(LoginPage);

        QMetaObject::connectSlotsByName(LoginPage);
    } // setupUi

    void retranslateUi(QMainWindow *LoginPage)
    {
        LoginPage->setWindowTitle(QCoreApplication::translate("LoginPage", "MainWindow", nullptr));
        signInGroupBox->setTitle(QCoreApplication::translate("LoginPage", "SignIn", nullptr));
        label->setText(QCoreApplication::translate("LoginPage", "User", nullptr));
        label_2->setText(QCoreApplication::translate("LoginPage", "Password", nullptr));
        loginPushButton->setText(QCoreApplication::translate("LoginPage", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginPage: public Ui_LoginPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINPAGE_H
